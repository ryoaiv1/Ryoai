// script.js
// Fixed UI script with robust guards, MutationObserver for dynamic code-block copy listeners,
// consistent prompt attribute usage, safer event binding, video upload/preview support,
// mic->send toggle fix and new-chat button fix.
// Changes: prompt-button clicks open suggestions (do NOT auto-send); suggestion items styled slightly.

let currentSuggestionKey = '';
let allSuggestions = [];

// Inject lightweight styles for suggestion items to "ظبط شكلها شويه"
(function injectSuggestionStyles() {
    try {
        const css = `
#suggestionsArea { background: rgba(0,0,0,0.45); padding: 8px; border-radius: 10px; max-height: 240px; overflow:auto; }
.suggestion-item {
  padding: 10px 12px;
  margin: 6px 0;
  border-radius: 8px;
  background: rgba(255,255,255,0.03);
  color: #fff;
  cursor: pointer;
  transition: background 120ms ease, transform 100ms ease;
  font-size: 14px;
  line-height: 1.4;
  border: 1px solid rgba(255,255,255,0.04);
}
.suggestion-item:hover {
  background: rgba(0,170,255,0.12);
  transform: translateY(-2px);
}
.suggestion-item:active { transform: translateY(0); }
.copy-success-badge { position: absolute; right: 12px; top: 8px; background: #0f9d58; color: white; padding: 6px 8px; border-radius: 6px; font-size: 12px; opacity: 0; transform: translate(-50%, 20px); transition: all 300ms ease; }
`;
        const s = document.createElement('style');
        s.setAttribute('data-injected-by', 'script.js-suggestions');
        s.appendChild(document.createTextNode(css));
        document.head && document.head.appendChild(s);
    } catch (e) {
        // ignore
    }
})();

function filterChatList() {
    const searchInput = document.getElementById('searchInput');
    const filter = (searchInput && searchInput.value) ? searchInput.value.toLowerCase() : ''; 
    const chatList = document.getElementById('chatList');
    if (!chatList) return;
    const items = chatList.getElementsByClassName('chat-list-item'); 

    for (let i = 0; i < items.length; i++) {
        let text = items[i].textContent || items[i].innerText; 
        
        if (text.toLowerCase().indexOf(filter) > -1) {
            items[i].style.display = ""; 
        } else {
            items[i].style.display = "none"; 
        }
    }
}

const suggestionSets = {
    'diet': [
        "تنظيم الوقت الغذائي لمتبعي نظام الكيتو.",
        "تنظيم الوقت الغذائي للرياضيين (بناء العضلات).",
        "تنظيم الوقت الغذائي لإنقاص الوزن بسرعة.",
        "تنظيم الوقت الغذائي لأشخاص لديهم حساسية الغلوتين.",
        "تنظيم الوقت الغذائي لمرضى السكري.",
    ],
    'study': [
        "تنظيم وقت للدراسة لمنهج جامعي ضخم.",
        "تنظيم وقت للدراسة بتقنية بومودورو.",
        "تنظيم وقت للدراسة خلال فترة الامتحانات النهائية.",
        "تنظيم وقت للدراسة مع عمل بدوام كامل.",
        "تنظيم وقت للدراسة لتعلم لغة جديدة.",
    ],
    'ai': [
        "أحدث تقنيات AI في مجال معالجة اللغة الطبيعية (NLP).",
        "أحدث تقنيات AI في مجال رؤية الكمبيوتر.",
        "أحدث تقنيات AI في مجال الروبوتات والقيادة الذاتية.",
        "أحدث تقنيات AI وكيف يمكن تطبيقها في التجارة الإلكترونية.",
        "أحدث تقنيات AI وتأثيرها على سوق العمل.",
    ]
};

function hideWelcomeScreen() {
    const welcomeScreen = document.getElementById('welcomeScreen');
    if (welcomeScreen && welcomeScreen.style.display !== 'none') {
        welcomeScreen.style.display = 'none';
    }
}

function restoreWelcomeContent() {
    const welcomeTitle = document.getElementById('welcomeTitle');
    const welcomeDescription = document.getElementById('welcomeDescription');
    const promptButtonContainer = document.getElementById('promptButtonContainer');
    
    if (!welcomeTitle || !welcomeDescription || !promptButtonContainer) return;
    
    welcomeTitle.style.display = 'block';
    welcomeDescription.style.display = 'block';
    promptButtonContainer.style.display = 'flex';
    
    setTimeout(() => {
        welcomeTitle.style.opacity = '1';
        welcomeDescription.style.opacity = '1';
        welcomeTitle.classList.remove('moved-up');
    }, 10);
}

function hideWelcomeContentElements() {
    const welcomeTitle = document.getElementById('welcomeTitle');
    const welcomeDescription = document.getElementById('welcomeDescription');
    const promptButtonContainer = document.getElementById('promptButtonContainer');
    if (!welcomeTitle || !welcomeDescription || !promptButtonContainer) return;
    
    welcomeTitle.style.opacity = '0';
    welcomeTitle.classList.add('moved-up'); 
    welcomeTitle.style.display = 'none';
    
    welcomeDescription.style.opacity = '0';
    welcomeDescription.style.display = 'none';
    
    promptButtonContainer.style.display = 'none';
}

function hideSuggestions() {
    const suggestionsArea = document.getElementById('suggestionsArea');
    if (!suggestionsArea) {
        currentSuggestionKey = '';
        return;
    }
    if (suggestionsArea.classList.contains('visible')) {
        reEnableTransitions(suggestionsArea); 
        suggestionsArea.classList.remove('visible'); 
        restoreWelcomeContent(); 
        setTimeout(() => {
            suggestionsArea.style.display = 'none';
        }, 300);
    }
    currentSuggestionKey = '';
}

function temporarilyDisableTransitions(element) {
    if (!element) return;
    element.style.transition = 'none';
    element.offsetHeight;
}

function reEnableTransitions(element) {
    if (!element) return;
    element.style.transition = ''; 
}

function renderSuggestions(filterText) {
    const suggestionsList = document.getElementById('suggestionsList');
    const suggestionsArea = document.getElementById('suggestionsArea');
    const textInput = document.getElementById('textInput');
    const sendButton = document.getElementById('sendButton');

    if (!suggestionsList || !suggestionsArea) return;

    const filteredSuggestions = allSuggestions.filter(suggestion => 
        suggestion.toLowerCase().includes((filterText || '').toLowerCase())
    );
    
    suggestionsList.innerHTML = '';
    temporarilyDisableTransitions(suggestionsArea);
    
    if (filteredSuggestions.length > 0) {
        filteredSuggestions.forEach(suggestion => {
            const item = document.createElement('div');
            item.className = 'suggestion-item'; 
            item.textContent = suggestion;
            
            item.addEventListener('click', () => {
                if (textInput) textInput.value = suggestion; 
                hideSuggestions(); 
                hideWelcomeScreen();
                if (typeof window.sendMessage === 'function') {
                    setTimeout(() => window.sendMessage(), 20);
                } else {
                    const sendBtn = document.getElementById('sendButton');
                    if (sendBtn) sendBtn.click();
                }
            });

            // small visual affordance: keyboard-selectable
            item.tabIndex = 0;
            item.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') item.click();
            });

            suggestionsList.appendChild(item);
        });

        suggestionsArea.style.display = 'block';
        suggestionsArea.classList.add('visible'); 
    } else {
        suggestionsArea.style.display = 'none';
        suggestionsArea.classList.remove('visible'); 
    }
    
    reEnableTransitions(suggestionsArea);

    if (textInput) {
        textInput.style.height = 'auto';
        textInput.style.height = (textInput.scrollHeight) + 'px';
    }
}

function showSuggestions(key) {
    const textInput = document.getElementById('textInput');
    const promptButton = document.querySelector(`.prompt-button[data-prompt-key="${key}"]`);
    const promptText = promptButton ? (promptButton.getAttribute('data-prompt-text') || '').trim() : '';
    
    hideWelcomeContentElements();

    if (textInput) textInput.value = promptText;
    currentSuggestionKey = key; 
    allSuggestions = suggestionSets[key] || [];
    
    renderSuggestions((promptText || '').toLowerCase()); 
    if (textInput) textInput.focus();
}

function trackInputClearance() {
    const textInput = document.getElementById('textInput');
    const filterText = textInput ? textInput.value.trim().toLowerCase() : '';
    if (!currentSuggestionKey) return; 
    if (filterText === '') {
        hideSuggestions();
        return;
    }
    renderSuggestions(filterText);
}

function displayCopySuccess(container) {
    if (!container) return;
    let successMessage = container.querySelector('.copy-success-badge');
    if (!successMessage) {
        successMessage = document.createElement('div');
        successMessage.className = 'copy-success-badge';
        successMessage.innerHTML = '<span class="material-icons-outlined">check</span> تم النسخ';
        container.appendChild(successMessage);
    }

    successMessage.style.opacity = '1';
    successMessage.style.transform = 'translate(-50%, -50%)';

    setTimeout(() => {
        successMessage.style.opacity = '0';
        successMessage.style.transform = 'translate(-50%, 20px)'; 
    }, 1500);
}

function fallbackCopyTextToClipboard(text, container) {
    if (!container) return;
    var textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.opacity = "0";

    container.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
        var successful = document.execCommand('copy');
        if (successful) {
            displayCopySuccess(container);
        } else {
             console.error('Fallback copy failed.');
        }
    } catch (err) {
        console.error('Fallback copy error:', err);
    }

    container.removeChild(textArea);
}

function copyCodeContent(codeContainer) {
    if (!codeContainer) return;
    const codeElement = codeContainer.querySelector('pre');
    if (codeElement) {
        const textToCopy = codeElement.textContent;

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(textToCopy)
                .then(() => {
                    displayCopySuccess(codeContainer);
                })
                .catch(err => {
                    console.error('Failed to copy using clipboard API: ', err);
                    fallbackCopyTextToClipboard(textToCopy, codeContainer);
                });
        } else {
            fallbackCopyTextToClipboard(textToCopy, codeContainer);
        }
    }
}

function applyCopyOnContainerClickListeners(root = document) {
    if (!root) return;
    const codeContainers = root.querySelectorAll('.code-block-container');
    
    codeContainers.forEach(container => {
        if (container.dataset.clickListenersApplied) return;
        container.dataset.clickListenersApplied = 'true';
        
        container.addEventListener('click', (event) => {
            if (event.target.closest('.print-code-button') || event.target.closest('.copy-success-badge') || event.target.closest('.copy-icon')) {
                return;
            }
            copyCodeContent(container);
        });
    });
}

(function initCodeBlockAutoAttach() {
    try {
        const target = document.getElementById('chatContainer') || document.body;
        const observer = new MutationObserver((mutations) => {
            for (const m of mutations) {
                if (!m.addedNodes) continue;
                m.addedNodes.forEach(node => {
                    try {
                        if (!(node instanceof HTMLElement)) return;
                        if (node.classList && node.classList.contains('code-block-container')) {
                            applyCopyOnContainerClickListeners(document);
                        } else {
                            const found = node.querySelector && node.querySelector('.code-block-container');
                            if (found) applyCopyOnContainerClickListeners(node);
                        }
                    } catch (err) {}
                });
            }
        });
        observer.observe(target, { childList: true, subtree: true });
    } catch (err) {
        console.warn("Code block observer init failed:", err);
    }
})();

document.addEventListener('DOMContentLoaded', () => {
    const themeToggleButton = document.getElementById('themeToggleButton');
    const body = document.body;
    const textInput = document.getElementById('textInput'); 
    const sendButton = document.getElementById('sendButton');
    
    // When clicking a prompt button: open the suggestions list (do NOT send automatically)
    document.querySelectorAll('.prompt-button').forEach(button => {
        button.addEventListener('click', () => {
            const promptKey = button.getAttribute('data-prompt-key');
            showSuggestions(promptKey);
        });
    });

    document.addEventListener('click', (e) => {
        if (e.target.classList && e.target.classList.contains('copy-code-icon')) {
            const container = e.target.closest('.code-block-container');
            const code = container && container.querySelector('pre') ? container.querySelector('pre').innerText : '';
            if (!code) return;
            navigator.clipboard.writeText(code).then(() => {
                e.target.innerText = "check";
                setTimeout(() => {
                    e.target.innerText = "content_copy";
                }, 1200);
            }).catch(err => {
                console.error("copy-code-icon click failed:", err);
            });
        }
    });

    const applyTheme = (theme) => {
        if (theme === 'light') {
            body.classList.add('light-mode');
            themeToggleButton && themeToggleButton.setAttribute('data-theme', 'light');
        } else {
            body.classList.remove('light-mode');
            themeToggleButton && themeToggleButton.setAttribute('data-theme', 'dark');
        }
        try { localStorage.setItem('theme', theme); } catch (e) {}
    };

    const savedTheme = (function(){ try { return localStorage.getItem('theme') || 'dark'; } catch (e) { return 'dark'; } })(); 
    applyTheme(savedTheme);

    if (themeToggleButton) {
        themeToggleButton.addEventListener('click', () => {
            const currentTheme = themeToggleButton.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            applyTheme(newTheme);
        });
    }
    
    const settingsButton = document.getElementById('settingsButton');
    const settingsOverlay = document.getElementById('settingsOverlay');
    const closeSettingsButton = document.getElementById('closeSettingsButton');

    if (settingsButton && settingsOverlay) {
        settingsButton.addEventListener('click', () => {
            settingsOverlay.style.display = 'block';
        });
    }
    if (closeSettingsButton && settingsOverlay) {
        closeSettingsButton.addEventListener('click', () => {
            settingsOverlay.style.display = 'none';
        });
    }
    
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', filterChatList);
    }

    if (sendButton) {
        sendButton.addEventListener('click', () => {
            hideWelcomeScreen();
            const suggestionsArea = document.getElementById('suggestionsArea');
            if (suggestionsArea && suggestionsArea.classList.contains('visible')) {
                hideSuggestions();
            }
            if (typeof window.sendMessage === 'function') {
                setTimeout(() => window.sendMessage(), 20);
            }
        });
    }
    
    if (textInput) {
        textInput.addEventListener('input', trackInputClearance);
    }

    applyCopyOnContainerClickListeners();
    setTimeout(() => applyCopyOnContainerClickListeners(), 50);

    // --- FIX: toggle mic/send based on input content or attachments preview
    const attachmentsPreview = document.getElementById('attachmentsPreview');
    const voiceButton = document.getElementById('voiceButton');

    function updateSendVoiceButtons() {
        try {
            const hasText = textInput && textInput.value && textInput.value.trim().length > 0;
            const hasAttachments = attachmentsPreview && attachmentsPreview.children && attachmentsPreview.children.length > 0;

            const shouldShowSend = hasText || hasAttachments;

            if (shouldShowSend) {
                if (sendButton) { sendButton.style.display = 'flex'; sendButton.style.pointerEvents = 'auto'; }
                if (voiceButton) voiceButton.style.display = 'none';
            } else {
                if (sendButton) { sendButton.style.display = 'none'; sendButton.style.pointerEvents = 'none'; }
                if (voiceButton) voiceButton.style.display = 'flex';
            }
        } catch (e) {
            console.error("updateSendVoiceButtons error:", e);
        }
    }

    updateSendVoiceButtons();

    if (textInput) {
        textInput.addEventListener('input', () => {
            textInput.style.height = 'auto';
            textInput.style.height = (textInput.scrollHeight) + 'px';
            updateSendVoiceButtons();
            trackInputClearance();
        });

        // Press Enter to send (Enter) — allow Shift+Enter for newline
        textInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                const suggestionsArea = document.getElementById('suggestionsArea');
                if (suggestionsArea && suggestionsArea.classList.contains('visible')) {
                    hideSuggestions();
                }
                if (typeof window.sendMessage === 'function') {
                    window.sendMessage();
                } else {
                    const sendBtn = document.getElementById('sendButton');
                    if (sendBtn) sendBtn.click();
                }
            }
        });
    }

    if (attachmentsPreview) {
        const apObserver = new MutationObserver(() => updateSendVoiceButtons());
        try { apObserver.observe(attachmentsPreview, { childList: true, subtree: true }); } catch (e) {}
    }

    // --- FIX: new chat pencil should start a new chat
    const newChatPencil = document.getElementById('newChatPencilButton');
    if (newChatPencil) {
        newChatPencil.addEventListener('click', (e) => {
            try { e.preventDefault(); e.stopPropagation(); } catch (err) {}
            if (typeof window.startNewChat === 'function') {
                window.startNewChat();
            } else {
                try { startNewChat(); } catch (err) { console.warn('startNewChat not available yet:', err); }
            }
        });
    }

    // Attach videoOption handler fallback (if needed)
    const videoOption = document.getElementById('videoOption');
    const fileInput = document.getElementById('fileInput');
    const videoInput = document.getElementById('videoInput');
    if (videoOption) {
        videoOption.addEventListener('click', () => {
            fadeOutAttachmentOptions();
            setTimeout(() => {
                if (videoInput) {
                    videoInput.accept = 'video/*';
                    videoInput.click();
                } else if (fileInput) {
                    const prev = fileInput.accept;
                    fileInput.accept = 'video/*';
                    fileInput.click();
                    setTimeout(() => { fileInput.accept = prev; }, 500);
                }
            }, 300);
        });
    }
});