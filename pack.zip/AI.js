/* AI.js */
'use strict';

const API_KEYS_POOL = [
    "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",
    "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",
    "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"
];
let currentAPIIndex = 0;

const GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
const FIREWORKS_ENDPOINT = "https://api.fireworks.ai/inference/v1/chat/completions";
const OPENAI_ENDPOINT = "https://api.openai.com/v1/chat/completions";
const GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1/models/";

const FIREWORKS_API_KEY = "fw_3ZTifxLqQxD9oaRWY3dcAZzP";
const OPENAI_API_KEY = "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";
const GEMINI_API_KEY = "AIzaSyCO7uODLYPS4P3VD10C2Wct7_s6YzhgtBA";

const CHAT_MODEL = 'llama-3.3-70b-versatile';
const VISION_MODEL = 'meta-llama/llama-4-scout-17b-16e-instruct';

const FIREWORKS_CHAT_MODEL = 'accounts/fireworks/models/gpt-oss-20b';
const FIREWORKS_VISION_MODEL = 'accounts/fireworks/models/llama4-maverick-instruct-basic';
const OPENAI_CHAT_MODEL = 'gpt-4o-mini';
const OPENAI_VISION_MODEL = 'gpt-4o-mini';
const GEMINI_CHAT_MODEL = 'gemini-2.5-flash';
const GEMINI_VISION_MODEL = 'gemini-2.5-flash';

const firebaseConfig = {
    apiKey: "AIzaSyAr5MrfA2KQCE87De5eMtTKYUU_81zZm1w",
    authDomain: "anisnow-a4735.firebaseapp.com",
    projectId: "anisnow-a4735",
    // CORRECTED storageBucket to the usual appspot.com domain:
    storageBucket: "anisnow-a4735.appspot.com",
    messagingSenderId: "312150783729",
    appId: "1:312150783729:web:cb62f5b64a7d5d9a069b50"
};

// Optional local/in-browser fallback configuration.
// Set window.useLocalModel = true to enable (default: true for fallback).
// WARNING: models run in-browser can be slow and heavy (not suitable for thousands of concurrent users).
window.useLocalModel = (typeof window.useLocalModel !== 'undefined') ? window.useLocalModel : true;
// Default local model name (Xenova-hosted small model). You can change to a different open model.
window.localModelName = window.localModelName || 'Xenova/gpt2';
// Local model generation options
window.localModelOptions = window.localModelOptions || { max_new_tokens: 256, temperature: 0.2 };

// State variables
let isAILoading = false; // ensure UI sync
let abortController = null; // legacy variable preserved
let controller = null; // main AbortController used for requests

// Initialize firebase if present (compat scripts expected to attach `firebase` to window)
let app = null;
let db = null;
try {
    if (typeof firebase !== 'undefined' && firebase && firebase.initializeApp) {
        try {
            app = firebase.initializeApp(firebaseConfig);
            db = firebase.firestore();
            // Ensure storage is available (storage compat script must be included in index.html)
            if (firebase.storage) {
                console.log("Firebase Storage available.");
            } else {
                console.warn("Firebase Storage not available (firebase.storage missing). Make sure firebase-storage-compat.js is included.");
            }
        } catch (e) {
            console.warn("Firebase initialization failed:", e);
            app = null;
            db = null;
        }
    } else {
        console.warn("Firebase SDK not found; Firestore features disabled.");
    }
} catch (e) {
    console.warn("Firebase check failed:", e);
}
function getOrCreateUserID() {
    let userId = null;
    try {
        userId = localStorage.getItem('ryo_user_id');
        if (!userId) {
            userId = 'user_' + Date.now() + Math.random().toString(36).substring(2, 9);
            localStorage.setItem('ryo_user_id', userId);
        }
    } catch (e) {
        // localStorage may throw in some environments
        userId = 'user_' + Date.now() + Math.random().toString(36).substring(2, 9);
    }
    return userId;
}

const CURRENT_USER_ID = getOrCreateUserID();
const MEMORIES_COLLECTION = 'ryo_memories';

// DOM element references (let so we can reassign safely if script runs early)
let chatContainer = document.getElementById('chatContainer');
let textInput = document.getElementById('textInput');
let sendButton = document.getElementById('sendButton');

// Voice UI elements
let voiceButton = document.getElementById('voiceButton');
let voiceModeIndicator = document.getElementById('voiceModeIndicator');

let welcomeScreen = document.getElementById('welcomeScreen');
let attachmentsPreview = document.getElementById('attachmentsPreview');
let chatContainerTemporaryMessage = document.getElementById('chatContainerTemporaryMessage');
let menuTemporaryMessage = document.getElementById('menuTemporaryMessage');

let editingMessageIndicator = document.getElementById('editingMessageIndicator');
let cancelEditButton = document.getElementById('cancelEditButton');

let saveToggleButton = document.getElementById('saveToggleButton');
let saveToggleIcon = document.getElementById('saveToggleIcon');
let saveToggleCheck = document.getElementById('saveToggleCheck');
let newChatPencilButton = document.getElementById('newChatPencilButton');
let menuButton = document.getElementById('menuButton');

let menuOverlay = document.getElementById('menuOverlay');
let chatList = document.getElementById('chatList');
let newChatButton = document.getElementById('newChatButton');
let deleteAllChatsButton = document.getElementById('deleteAllChatsButton');

let attachmentButton = document.getElementById('attachmentButton');
let attachmentOptions = document.getElementById('attachmentOptions');
let photoInput = document.getElementById('photoInput');
let fileInput = document.getElementById('fileInput');
let cameraInput = document.getElementById('cameraInput');
let videoInput = document.getElementById('videoInput'); // may be present in index.html

let stopButton = document.getElementById('stopButton');

let loadingMessageElement = null;
let currentChatId = null;
let currentChatHistory = [];
let attachedFiles = [];
let abortTyping = false;
let editingMessageData = null;

// Voice state
let isVoiceModeActive = false;
let recognition = null;
let synthesis = window.speechSynthesis || null;
let isSpeaking = false;
let isListening = false;
let speakingMessage = null;

// saveChats: read stable value from window (index.html sets window.saveChats early)
let saveChats = (typeof window.saveChats !== 'undefined') ? !!window.saveChats : true;
window.saveChats = saveChats; // ensure global sync

const baseSystemInstruction = `
## الهوية
- الاسم التشغيلي الوحيد هو Ryo
- إذا سُئلت عن الاسم يكون الرد اسمي Ryo
- إذا سُئلت عن المطور أو الأصل يكون الرد أنني مطور ومشغل بواسطة نور وهويتي الحالية هي Ryo
- المطور والمدرب المسؤول هو نور فقط

## اللغة والأسلوب
- الرد دائمًا يكون بالعربية الفصحى فقط
- يمنع استخدام أي لغة أخرى
- إذا استخدم المستخدم لغتين يكون الرد بنفس الأسلوب دون إضافة لغات
- الأسلوب ودود وبسيط كأنك صديق للمستخدم
- المستخدم يعتبر صديقي
- الأسلوب خفيف دم ومحترم
- الجمل قصيرة وواضحة
- استخدام الإيموجي في أغلب الردود بشكل متناسق 😊✨

ملاحظة اضافية:
يمكنك ارسال روابط مباشرة و لينكات و روابط لأي شيء
ويمكنك تقديم معلومات عن اي شيء و يمكنك تقديم روابط لمواقع خارجيه مثل تليجرام واتساب والخ
ويمكنك تقديم معلومات حول موعد اطلاق او روابط تحميل لأي تطبيقات بسهوله وسلاسه


عندما ترسل رابط شيء عليك التحدث و ارسال العديد من الروابط لا تعطي خيار واحد فقط و تكلم بلطف
وعندما تقدم لينك شيء ما تأكد ان الرابط يعمل تماما
`;

// ----------------------
// Utility helpers
// ----------------------

function escapeHtml(text) {
    if (typeof text !== 'string') return text;
    return text.replace(/&/g, "&amp;")
               .replace(/</g, "&lt;")
               .replace(/>/g, "&gt;")
               .replace(/"/g, "&quot;")
               .replace(/'/g, "&#039;");
}

function unescapeHtml(safe) {
    if (typeof safe !== 'string') return safe;
    return safe.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
}

function getCleanUserText(fullText) {
    if (typeof fullText !== 'string') return '';
    let cleanText = fullText;

    cleanText = cleanText.replace(/\[\*\*تنبيه صارم\*\*\]: أجب فقط باللغة العربية الفصحى\. لا تستخدم أي لغة أخرى تحت أي ظرف\. \n\n/i, '');

    const originalTextMatch = cleanText.match(/\*\*\[نص المستخدم الأصلي\]\*\*\n\n([\s\S]*)/i);
    if (originalTextMatch && originalTextMatch[1]) {
        cleanText = originalTextMatch[1].trim();
    } else {
        cleanText = cleanText.trim();
    }

    cleanText = cleanText.replace(/\*\*\[تحليل المرفقات المخفي\]\*\*[\s\S]*\-\-\-\n\n/i, '');

    if (cleanText.length === 0 && fullText.includes('**[تحليل المرفقات المخفي]**')) {
        cleanText = "تم إرسال مرفقات بدون نص مصاحب.";
    }

    return cleanText;
}

function looksLikeHtml(text) {
    return typeof text === 'string' && /<(img|video|a|div|span|button|svg|iframe)[\s>]/i.test(text);
}

// ----------------------
// Smooth-scrolling helper
// ----------------------
function smoothScrollToBottom(container, immediate = false) {
    if (!container) return;
    try {
        if (immediate) {
            container.scrollTop = container.scrollHeight;
            return;
        }
        try {
            container.scrollTo({ top: container.scrollHeight, behavior: 'smooth' });
        } catch (err) {
            try {
                const last = container.lastElementChild;
                if (last && typeof last.scrollIntoView === 'function') {
                    last.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
                } else {
                    container.scrollTop = container.scrollHeight;
                }
            } catch (err2) {
                container.scrollTop = container.scrollHeight;
            }
        }
    } catch (e) {
        try { container.scrollTop = container.scrollHeight; } catch (e2) {}
    }
}

// ----------------------
// Media parsing + insertion helpers
// ----------------------

function parseMediaFromText(text) {
    if (!text || typeof text !== 'string') return null;

    // 1) If it contains a data URL for image or video
    const dataUrlMatch = text.match(/(data:(image|video)\/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=]+)/);
    if (dataUrlMatch) {
        const dataUrl = dataUrlMatch[1];
        const isImage = dataUrl.startsWith('data:image');
        return {
            type: isImage ? 'image' : 'video',
            format: 'data_url',
            dataUrl: dataUrl,
            caption: null
        };
    }

    // 2) Try to extract JSON object (either inside ```json``` code block or plain JSON)
    const jsonBlockMatch = text.match(/```json\s*([\s\S]*?)\s*```/i);
    if (jsonBlockMatch && jsonBlockMatch[1]) {
        try {
            const parsed = JSON.parse(jsonBlockMatch[1].trim());
            if (parsed && (parsed.type === 'image' || parsed.type === 'video')) {
                if (parsed.format === 'data_url' && parsed.data) {
                    return {
                        type: parsed.type,
                        format: 'data_url',
                        dataUrl: parsed.data.startsWith('data:') ? parsed.data : (`data:${parsed.mime || (parsed.type==='image'?'image/png':'video/mp4')};base64,${parsed.data}`),
                        caption: parsed.caption || null
                    };
                } else if (parsed.format === 'url' && parsed.url) {
                    return {
                        type: parsed.type,
                        format: 'url',
                        url: parsed.url,
                        caption: parsed.caption || null
                    };
                } else if (parsed.format === 'frames' && Array.isArray(parsed.frames)) {
                    return {
                        type: 'video',
                        format: 'frames',
                        frames: parsed.frames,
                        fps: parsed.fps || 8,
                        mime: parsed.mime || 'video/webm',
                        caption: parsed.caption || null
                    };
                }
            }
        } catch (e) {
            // ignore parse errors
        }
    }

    // 3) Try to find first JSON-like object in text (naive)
    const firstBraceIndex = text.indexOf('{');
    if (firstBraceIndex !== -1) {
        for (let end = text.length; end > firstBraceIndex; end--) {
            const candidate = text.substring(firstBraceIndex, end);
            try {
                const parsed = JSON.parse(candidate);
                if (parsed && (parsed.type === 'image' || parsed.type === 'video')) {
                    if (parsed.format === 'data_url' && parsed.data) {
                        return {
                            type: parsed.type,
                            format: 'data_url',
                            dataUrl: parsed.data.startsWith('data:') ? parsed.data : (`data:${parsed.mime || (parsed.type==='image'?'image/png':'video/mp4')};base64,${parsed.data}`),
                            caption: parsed.caption || null
                        };
                    } else if (parsed.format === 'url' && parsed.url) {
                        return {
                            type: parsed.type,
                            format: 'url',
                            url: parsed.url,
                            caption: parsed.caption || null
                        };
                    } else if (parsed.format === 'frames' && Array.isArray(parsed.frames)) {
                        return {
                            type: 'video',
                            format: 'frames',
                            frames: parsed.frames,
                            fps: parsed.fps || 8,
                            mime: parsed.mime || 'video/webm',
                            caption: parsed.caption || null
                        };
                    }
                }
            } catch (e) {
                // continue trying
            }
        }
    }

    // 4) Try to find a plain http(s) URL and infer type from extension
    const urlMatch = text.match(/(https?:\/\/[^\s'"]+)/);
    if (urlMatch) {
        const url = urlMatch[1];
        const lower = url.toLowerCase();
        const imageExt = /\.(png|jpe?g|gif|webp|bmp)(\?|$)/i;
        const videoExt = /\.(mp4|mov|webm|mkv|avi)(\?|$)/i;
        if (imageExt.test(lower)) {
            return { type: 'image', format: 'url', url: url, caption: null };
        }
        if (videoExt.test(lower)) {
            return { type: 'video', format: 'url', url: url, caption: null };
        }
        // Generic URL
        return { type: 'unknown', format: 'url', url: url, caption: null };
    }

    // 5) If starts with "ERROR:" then return as error indicator
    const errMatch = text.match(/^\s*ERROR:\s*(.+)$/i);
    if (errMatch) {
        return { type: 'error', message: errMatch[1].trim() };
    }

    return null;
}

async function makeObjectUrlFromDataUrl(dataUrl) {
    // fetch works with data URLs in modern browsers
    const resp = await fetch(dataUrl);
    const blob = await resp.blob();
    return URL.createObjectURL(blob);
}

async function insertMediaMessage(parsedMedia, originalText = '') {
    if (!parsedMedia) return null;

    try {
        // BLOCK generation of inline data images/videos (user requested no creation of images/videos)
        if (parsedMedia.format === 'data_url' || parsedMedia.format === 'frames') {
            const msg = 'عذراً، لا يمكنني إنشاء صور أو فيديوهات مباشرةً هنا.';
            const md = createMessageElement(msg, 'ai', [], null, false);
            // Speak a short message so user knows
            try { speakResponse('عذراً، لا يمكنني إنشاء صور أو فيديوهات حالياً.'); } catch (e) {}
            return md;
        }

        // If it's a URL:
        if (parsedMedia.format === 'url') {
            const safeUrl = parsedMedia.url ? parsedMedia.url.trim() : '';
            const escapedUrl = escapeHtml(safeUrl);

            // For videos, show the link and a play icon below which opens the link when clicked.
            if (parsedMedia.type === 'video') {
                const html = `
<div class="generated-link-wrapper">
  <a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="ai-link">${escapedUrl}</a>
  <div class="video-play-wrapper" style="margin-top:8px;">
    <button class="video-play-button" data-url="${escapedUrl}" aria-label="فتح الفيديو" title="فتح الفيديو" style="display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:8px;border:none;background:transparent;color:inherit;cursor:pointer;">
      <span class="material-icons-outlined" style="font-size:28px;">play_circle_filled</span>
      <span style="font-size:0.9em;opacity:0.9">فتح الفيديو</span>
    </button>
  </div>
</div>
`;
                const el = createMessageElement(html, 'ai', [], null, true);
                // Announce
                try { speakResponse('أرسلت رابط فيديو. اضغط على أيقونة التشغيل لفتحه.'); } catch (e) {}
                return el;
            }

            // For images or unknown links, show safe anchor and a small icon (but do not embed image/video)
            const html = `<div class="generated-link-wrapper"><a href="${escapedUrl}" target="_blank" rel="noopener noreferrer" class="ai-link">${escapedUrl}</a></div>`;
            const el = createMessageElement(html, 'ai', [], null, true);
            try { speakResponse('أرسلت رابطًا. افتحه بالضغط على الرابط.'); } catch (e) {}
            return el;
        }

        // Fallback: if parsedMedia indicates error
        if (parsedMedia.type === 'error') {
            const html = `**خطأ في إنشاء الوسائط:** ${escapeHtml(parsedMedia.message)}`;
            return createMessageElement(html, 'ai', [], null, false);
        }
    } catch (err) {
        console.warn("insertMediaMessage failed:", err);
    }

    // fallback: display originalText
    return createMessageElement(originalText, 'ai', [], null, false);
}

// ----------------------
// Video frame extraction & image-data analysis helpers
// ----------------------

// Extract a representative frame (middle or 0.5s) from a video File and return a dataURL (jpeg)
function extractFrameFromVideo(file, seekTime = 0.5, timeoutMs = 5000) {
    return new Promise((resolve, reject) => {
        try {
            const url = URL.createObjectURL(file);
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.muted = true;
            video.src = url;
            video.crossOrigin = 'anonymous';

            let resolved = false;
            const cleanup = () => {
                try { URL.revokeObjectURL(url); } catch (e) {}
                try { video.remove(); } catch (e) {}
            };

            const onError = (e) => {
                if (resolved) return;
                resolved = true;
                cleanup();
                reject(new Error('Maintenance available'));
            };

            const onLoaded = () => {
                const duration = video.duration || 0;
                const t = Math.min(seekTime, Math.max(0.05, duration / 2));
                const seekHandler = () => {
                    try {
                        const canvas = document.createElement('canvas');
                        canvas.width = video.videoWidth || 640;
                        canvas.height = video.videoHeight || 360;
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                        if (!resolved) {
                            resolved = true;
                            cleanup();
                            resolve(dataUrl);
                        }
                    } catch (err) {
                        if (!resolved) {
                            resolved = true;
                            cleanup();
                            reject(err);
                        }
                    }
                };

                const onSeeked = () => {
                    seekHandler();
                };

                video.currentTime = t;
                video.addEventListener('seeked', onSeeked, { once: true });
            };

            const timer = setTimeout(() => {
                if (!resolved) {
                    resolved = true;
                    cleanup();
                    reject(new Error('انتهت المهلة أثناء استخراج إطار الفيديو.'));
                }
            }, timeoutMs);

            video.addEventListener('loadeddata', () => {
                try {
                    onLoaded();
                    clearTimeout(timer);
                } catch (e) {
                    onError(e);
                    clearTimeout(timer);
                }
            }, { once: true });

            video.addEventListener('error', (e) => {
                onError(e);
                clearTimeout(timer);
            }, { once: true });

            video.addEventListener('loadedmetadata', () => {
                // no-op
            }, { once: true });

        } catch (err) {
            reject(err);
        }
    });
}

async function analyzeImageDataURLWithVisionModel(dataUrl, filename = 'image.jpg', userPrompt = '') {
    if (!dataUrl || typeof dataUrl !== 'string') {
        return "Maintenance available";
    }

    const visionMessageContent = [
        { type: "text", text: userPrompt || "صف هذه الصورة." },
        { type: "image_url", image_url: { url: dataUrl } }
    ];

    const payload = {
        model: VISION_MODEL,
        messages: [{ role: "user", content: visionMessageContent }],
        stream: false
    };

    try {
        const result = await callMultiAPI(payload, controller ? controller.signal : undefined, true);
        const analysisText = result.data.choices?.[0]?.message?.content || "عذراً، لم أتلق إجابة من نموذج الرؤية.";
        return analysisText;
    } catch (err) {
        if (err && err.name === 'AbortError') throw err;
        return `خطأ أثناء تحليل الصورة: ${err?.message || String(err)}`;
    }
}

// ----------------------
// Existing functions (kept, with targeted fixes)
// ----------------------

function startVoiceMode() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        alert("عذراً! متصفحك لا يدعم التعرف على الكلام (Web Speech API). يفضل استخدام Google Chrome.");
        return;
    }

    if (isSpeaking && synthesis) {
        try { synthesis.cancel(); } catch (e) {}
        isSpeaking = false;
    }

    isVoiceModeActive = true;
    isListening = true;

    if (voiceModeIndicator) voiceModeIndicator.classList.add('active');
    if (voiceButton) voiceButton.classList.add('recording');

    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'ar-EG';

    recognition.onstart = () => {
        console.log("Listening started...");
        isListening = true;
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('speaking');
        if (voiceModeIndicator) voiceModeIndicator.classList.add('listening');
    };

    recognition.onresult = (event) => {
        isListening = false;
        try {
            const transcript = event.results[0][0].transcript;
            if (textInput) {
                textInput.value = transcript;
                textInput.dispatchEvent(new Event('input'));
            }
            stopVoiceMode(true, transcript);
        } catch (err) {
            console.warn("Speech recognition result parsing failed:", err);
            stopVoiceMode(false);
        }
    };

    recognition.onerror = (event) => {
        console.error("Speech recognition error:", event.error);
        stopVoiceMode(false);
        if (event.error !== 'no-speech') {
            try { alert(`خطأ في التعرف على الصوت: ${event.error}`); } catch (e) {}
        }
    };

    recognition.onend = () => {
        console.log("Listening ended.");
        isListening = false;
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('listening');
        if (voiceButton) voiceButton.classList.remove('recording');

        if (isVoiceModeActive) {
            stopVoiceMode(false);
        }
    };

    try {
        recognition.start();
    } catch (e) {
        console.warn("Recognition already started or other error:", e);
    }
}

function stopVoiceMode(shouldSend = false, text = '') {
    if (!isVoiceModeActive && !isListening) return;

    isVoiceModeActive = false;
    isListening = false;

    if (recognition) {
        try { recognition.stop(); } catch (e) { /* ignore */ }
        recognition = null;
    }

    if (voiceModeIndicator) voiceModeIndicator.classList.remove('active');
    if (voiceModeIndicator) voiceModeIndicator.classList.remove('listening');
    if (voiceButton) voiceButton.classList.remove('recording');

    if (shouldSend && text && text.trim()) {
        if (textInput) {
            textInput.value = text;
            textInput.dispatchEvent(new Event('input'));
        }
        sendMessage();
    }
}

function speakResponse(text) {
    if (!text) return;
    if (!synthesis) {
        try {
            synthesis = window.speechSynthesis || null;
        } catch (e) {
            synthesis = null;
        }
    }
    if (!synthesis) return;

    try {
        synthesis.cancel();
    } catch (e) {}

    isSpeaking = true;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';
    utterance.rate = 1.0;

    const voices = synthesis.getVoices ? synthesis.getVoices() : [];
    const arabicVoice = voices.find(voice => voice.lang && voice.lang.startsWith('ar') && voice.name && voice.name.toLowerCase().includes('elsa')) || voices.find(v => v.lang && v.lang.startsWith('ar'));
    if (arabicVoice) {
        utterance.voice = arabicVoice;
    }

    utterance.onstart = () => {
        isSpeaking = true;
        if (voiceModeIndicator) voiceModeIndicator.classList.add('active');
        if (voiceModeIndicator) voiceModeIndicator.classList.add('speaking');
    };

    utterance.onend = () => {
        isSpeaking = false;
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('speaking');
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('active');

        if (isVoiceModeActive) {
            setTimeout(() => {
                startVoiceMode();
            }, 200);
        }
    };

    utterance.onerror = (event) => {
        console.error("Speech synthesis error:", event.error);
        isSpeaking = false;
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('speaking');
        if (voiceModeIndicator) voiceModeIndicator.classList.remove('active');
    };

    try {
        synthesis.speak(utterance);
    } catch (e) {
        console.warn("synthesis.speak failed:", e);
    }
}

if (voiceButton) {
    voiceButton.addEventListener('click', () => {
        if (!isAILoading) {
             if (isListening || isSpeaking) {
                 stopVoiceMode(false);
             } else {
                 startVoiceMode();
             }
        }
    });
}

// formatResponseWithCodeBlocks: improved to preserve code newlines (avoid post-replace \n -> <br> inside pre)
function formatResponseWithCodeBlocks(markdownText) {
    if (typeof markdownText !== 'string') return markdownText || '';

    // Extract code blocks and replace with placeholders
    const codeBlocks = [];
    const placeholderPrefix = '___CODEBLOCK_PLACEHOLDER_';
    let index = 0;

    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)\n```/g;
    let tmp = markdownText.replace(codeBlockRegex, (match, lang, code) => {
        const language = lang || 'plaintext';
        const escapedCode = escapeHtml(code.trim());
        const blockHtml = `
<div class="code-block-container" dir="ltr">
    <div class="code-header">
        <span class="copy-icon material-icons-outlined">content_copy</span>
        <span class="code-lang-label">${language}</span>
    </div>
    <pre class="language-${language}">${escapedCode}</pre>
</div>
`;
        const placeholder = `${placeholderPrefix}${index}___`;
        codeBlocks.push({ placeholder, html: blockHtml });
        index++;
        return placeholder;
    });

    // Convert remaining markdown to basic HTML (safe transforms)
    let processedText = tmp;

    const urlRegex = /(https?:\/\/[^\s<]+)/g;
    processedText = processedText.replace(urlRegex, '<a href="$1" target="_blank" class="ai-link" style="color: #00aaff; text-decoration: underline;">$1</a>');

    processedText = processedText.replace(/`([^`]+)`/g, '<code>$1</code>');
    processedText = processedText.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    processedText = processedText.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    processedText = processedText.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    processedText = processedText.replace(/^\* (.*$)/gim, '<ul><li>$1</li></ul>');
    processedText = processedText.replace(/<\/ul>\n<ul>/gim, '');
    processedText = processedText.replace(/\*\*(.*?)\*\*/gim, '<b>$1</b>');

    // Convert newlines outside codeblocks
    processedText = processedText.replace(/\n/g, '<br>');

    // restore code blocks placeholders
    codeBlocks.forEach(cb => {
        processedText = processedText.replace(cb.placeholder, cb.html);
    });

    return processedText;
}

function hideAllEditButtons() {
    document.querySelectorAll('.edit-controls.visible').forEach(btn => {
        btn.classList.remove('visible');
    });
}

function finalizeMessageDisplay(contentDiv) {
    try {
        // Attach copy handlers for code blocks
        contentDiv.querySelectorAll('.copy-icon').forEach(icon => {
            if (icon.dataset.listenerApplied) return;
            icon.dataset.listenerApplied = 'true';

            icon.addEventListener('click', () => {
                const container = icon.closest('.code-block-container');
                const codeText = container?.querySelector('pre')?.innerText || "";

                if (!codeText) return;

                navigator.clipboard.writeText(codeText).then(() => {
                    icon.textContent = "check";

                    setTimeout(() => {
                        icon.textContent = "content_copy";
                    }, 1200);

                }).catch(err => {
                    console.error("Copy failed:", err);
                });
            });
        });

        // Attach video-play-button click handlers (open URL)
        contentDiv.querySelectorAll('.video-play-button').forEach(btn => {
            if (btn.dataset.listenerApplied) return;
            btn.dataset.listenerApplied = 'true';
            btn.addEventListener('click', (e) => {
                try {
                    const url = btn.getAttribute('data-url');
                    if (!url) return;
                    // open in new tab
                    window.open(url, '_blank', 'noopener');
                    // speak short confirmation
                    try { speakResponse('تم فتح الفيديو في نافذة جديدة.'); } catch (e) {}
                } catch (err) {
                    console.error("video-play-button click failed:", err);
                }
            });
        });

        if (typeof hljs !== 'undefined') {
            contentDiv.querySelectorAll('.code-block-container pre').forEach((block) => {
                try {
                    hljs.highlightElement(block);
                } catch (err) {
                    console.warn("hljs highlight failed:", err);
                }
            });
        }
    } catch (err) {
        console.error("finalizeMessageDisplay error:", err);
    }
}

// Minimal edit-mode functions (were referenced but not defined in original)
function startEditMode(msgId, originalText, messageDiv) {
    try {
        editingMessageData = {
            msgId: msgId,
            messageDiv: messageDiv,
            originalText: originalText
        };
        if (editingMessageIndicator) editingMessageIndicator.style.display = 'flex';
        if (textInput) {
            textInput.value = getCleanUserText(originalText || '');
            textInput.focus();
            textInput.dispatchEvent(new Event('input'));
        }
        if (sendButton) sendButton.innerHTML = '<span class="material-icons-outlined">done</span>';
    } catch (err) {
        console.warn("startEditMode failed:", err);
    }
}

function exitEditMode() {
    try {
        editingMessageData = null;
        if (editingMessageIndicator) editingMessageIndicator.style.display = 'none';
        if (sendButton) sendButton.innerHTML = '<span class="material-icons-outlined">send</span>';
        if (textInput) {
            textInput.value = '';
            textInput.style.height = 'auto';
            textInput.dispatchEvent(new Event('input'));
        }
    } catch (err) {
        console.warn("exitEditMode failed:", err);
    }
}

// New helper: create controls (نسخ، طباعة) for AI messages
function createAIControls(contentDiv, rawText) {
    try {
        const controls = document.createElement('div');
        controls.className = 'ai-controls message-controls';

        // Copy button
        const copyBtn = document.createElement('button');
        copyBtn.className = 'control-button copy-ai-button';
        copyBtn.title = 'نسخ';
        copyBtn.setAttribute('aria-label', 'نسخ نص الرسالة');
        copyBtn.innerHTML = '<span class="material-icons-outlined">content_copy</span>';

        copyBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const payload = rawText || contentDiv.innerText || contentDiv.textContent || '';
            if (!payload) return;
            try {
                await navigator.clipboard.writeText(payload);
                // visual feedback: temporarily change icon
                const icon = copyBtn.querySelector('.material-icons-outlined');
                if (icon) {
                    const prev = icon.textContent;
                    icon.textContent = 'check';
                    setTimeout(() => { icon.textContent = prev; }, 1200);
                }
            } catch (err) {
                // fallback
                const ta = document.createElement('textarea');
                ta.value = payload;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                try {
                    document.execCommand('copy');
                    displayCopyFeedback(copyBtn);
                } catch (e) {
                    console.error('Fallback copy failed', e);
                }
                document.body.removeChild(ta);
            }
        });

        // Print button
        const printBtn = document.createElement('button');
        printBtn.className = 'control-button print-ai-button';
        printBtn.title = 'طباعة';
        printBtn.setAttribute('aria-label', 'طباعة محتوى الرسالة');

        printBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            try {
                const win = window.open('', '_blank', 'noopener');
                if (!win) {
                    alert('تعذر فتح نافذة الطباعة. تحقق من إعدادات المتصفح.');
                    return;
                }

                // Determine theme and inline some basic styles to respect light/dark mode
                const isLight = document.body && document.body.classList && document.body.classList.contains('light-mode');
                const bg = isLight ? '#fff' : '#000';
                const text = isLight ? '#000' : '#fff';
                const dir = document.documentElement && document.documentElement.dir ? document.documentElement.dir : 'rtl';

                const html = `
<!doctype html>
<html dir="${dir}">
<head>
<meta charset="utf-8">
<title>طباعة - Ryo</title>
<style>
  body { background: ${bg}; color: ${text}; font-family: Arial, sans-serif; padding: 20px; box-sizing: border-box; }
  a { color: ${isLight ? '#0066cc' : '#4da6ff'}; }
  pre { background: transparent; color: ${text}; white-space: pre-wrap; word-wrap: break-word; font-family: monospace; }
  img { max-width: 100%; height: auto; }
</style>
</head>
<body>
<div>${contentDiv.innerHTML}</div>
</body>
</html>
                `;
                win.document.open();
                win.document.write(html);
                win.document.close();
                // Give the window a moment to render
                setTimeout(() => {
                    try {
                        win.focus();
                        win.print();
                        // Optionally close after print (some browsers block)
                        // win.close();
                    } catch (err) {
                        console.error('Print failed:', err);
                    }
                }, 300);
            } catch (err) {
                console.error('printBtn handler error:', err);
            }
        });

        controls.appendChild(copyBtn);
        controls.appendChild(printBtn);

        // append controls below contentDiv
        contentDiv.parentNode && contentDiv.parentNode.appendChild(controls);

    } catch (err) {
        console.error("createAIControls error:", err);
    }
}

function displayCopyFeedback(container) {
    try {
        const badge = document.createElement('div');
        badge.className = 'copy-badge';
        badge.textContent = 'تم النسخ';
        badge.style.opacity = '0';
        badge.style.transition = 'opacity 200ms';
        container.parentNode && container.parentNode.appendChild(badge);
        setTimeout(() => { badge.style.opacity = '1'; }, 10);
        setTimeout(() => { badge.style.opacity = '0'; setTimeout(() => badge.remove(), 300); }, 1200);
    } catch (e) {}
}

async function createMessageElement(text, sender, files = [], msgId = null, isImmediateDisplay = false) {
    hideAllEditButtons();

    if (welcomeScreen) welcomeScreen.style.display = 'none';
    if (chatContainerTemporaryMessage) chatContainerTemporaryMessage.style.display = saveChats ? 'none' : 'flex';

    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;

    const contentDiv = document.createElement('div');
    contentDiv.className = `${sender}-message-content`;

    const finalMsgId = msgId || `msg-${Date.now()}`;

    if (sender === 'user' && files.length > 0) {
        const filesContainer = document.createElement('div');
        filesContainer.className = 'attachment-files-container';

        files.forEach(file => {
            const filePreview = document.createElement('div');
            filePreview.className = 'attachment-item-display';

            const fileUrl = file.url || (file.file ? URL.createObjectURL(file.file) : null);

            if (file.mimeType && file.mimeType.startsWith('image') && fileUrl) {
                filePreview.className = 'attachment-item-display image-attachment-display';
                const img = document.createElement('img');
                img.src = fileUrl;
                filePreview.appendChild(img);
            } else {
                const fileType = (file.name || 'FILE').split('.').pop().toUpperCase();
                const displayType = fileType.substring(0, 4);

                filePreview.className = 'attachment-item-display custom-file-icon';
                filePreview.innerHTML = `
                    <div class="file-icon-wrapper">
                        <span class="file-fold-corner"></span>
                        <span class="file-type-text">${displayType}</span>
                    </div>
                `;
            }

            filesContainer.appendChild(filePreview);
        });
        messageDiv.appendChild(filesContainer);
    }

    let cleanText = text;
    let originalTextToStore = text;

    if (sender === 'user') {
        cleanText = getCleanUserText(text);
    }

    messageDiv.appendChild(contentDiv);

    if (sender === 'user') {
        messageDiv.id = finalMsgId;

        let formattedText = cleanText.replace(/`([^`]+)`/g, '<code>$1</code>');
        formattedText = formattedText.replace(/\n/g, '<br>');

        contentDiv.innerHTML = formattedText;
        contentDiv.setAttribute('data-msg-id', finalMsgId);
        contentDiv.setAttribute('data-original-text', originalTextToStore);

        const editControls = document.createElement('div');
        editControls.className = 'edit-controls';

        const editButton = document.createElement('button');
        editButton.className = 'edit-message-button';
        editButton.innerHTML = '<span class="material-icons-outlined">edit</span> تعديل';

        const copyMsgButton = document.createElement('button');
        copyMsgButton.className = 'edit-message-button copy-message-button';
        copyMsgButton.innerHTML = '<span class="material-icons-outlined">content_copy</span> نسخ';

        copyMsgButton.addEventListener('click', (e) => {
            e.stopPropagation();

            const fullOriginalText = unescapeHtml(contentDiv.getAttribute('data-original-text')) || text;
            const cleanTextToCopy = getCleanUserText(fullOriginalText);

            navigator.clipboard.writeText(cleanTextToCopy).then(() => {
                copyMsgButton.innerHTML = '<span class="material-icons-outlined">check</span> تم النسخ';
                setTimeout(() => {
                    copyMsgButton.innerHTML = '<span class="material-icons-outlined">content_copy</span> نسخ';
                    editControls.classList.remove('visible');
                }, 1000);
            }).catch(err => {
                console.error("Copy user message failed:", err);
            });
        });

        const controlsGroup = document.createElement('div');
        controlsGroup.style.display = 'flex';
        controlsGroup.style.flexDirection = 'column';
        controlsGroup.style.gap = '2px';

        controlsGroup.appendChild(editButton);
        controlsGroup.appendChild(copyMsgButton);
        editControls.appendChild(controlsGroup);

        editButton.addEventListener('click', (e) => {
            e.stopPropagation();
            const fullOriginalText = contentDiv.getAttribute('data-original-text');
            startEditMode(finalMsgId, fullOriginalText, messageDiv);
        });

        let pressTimer;
        contentDiv.addEventListener('touchstart', (e) => {
            e.stopPropagation();
            hideAllEditButtons();
            pressTimer = setTimeout(() => { editControls.classList.add('visible'); }, 800);
        });
        contentDiv.addEventListener('touchend', () => { clearTimeout(pressTimer); });
        contentDiv.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            hideAllEditButtons();
            editControls.classList.add('visible');
        });
        messageDiv.appendChild(editControls);
        if (chatContainer) chatContainer.appendChild(messageDiv);

    } else {
        // For assistant/ai messages: ensure they are visible when rendering from storage
        if (editingMessageData && !isImmediateDisplay) {
            const userMessageDiv = editingMessageData.messageDiv;
            if (userMessageDiv && userMessageDiv.parentNode) {
                userMessageDiv.parentNode.insertBefore(messageDiv, userMessageDiv.nextSibling);
            } else {
                if (chatContainer) chatContainer.appendChild(messageDiv);
            }
            exitEditMode();
        } else {
             if (chatContainer) chatContainer.appendChild(messageDiv);
        }

        // If text appears to already be HTML (e.g., insertMediaMessage passed prepared HTML), do not re-run markdown->HTML
        if (isImmediateDisplay && looksLikeHtml(text)) {
            contentDiv.innerHTML = text;
            try {
                contentDiv.style.visibility = 'visible';
                contentDiv.style.opacity = '1';
                if (contentDiv.style.display === 'none') contentDiv.style.display = 'block';
            } catch (e) {}
            // Append AI controls for HTML message
            createAIControls(contentDiv, text);
            finalizeMessageDisplay(contentDiv);
        } else {
            contentDiv.innerHTML = formatResponseWithCodeBlocks(text);
            if (isImmediateDisplay) {
                try {
                    contentDiv.style.visibility = 'visible';
                    contentDiv.style.opacity = '1';
                    if (contentDiv.style.display === 'none') contentDiv.style.display = 'block';
                } catch (e) {}
            } else {
                contentDiv.classList.add('fade-in-message');
                try {
                    contentDiv.style.visibility = 'visible';
                    contentDiv.style.opacity = '1';
                } catch (e) {}
            }
            // Append AI controls for generated text (raw text passed)
            createAIControls(contentDiv, text);
            finalizeMessageDisplay(contentDiv);
        }
    }

    if (chatContainer) {
        // Smoothly scroll the newly added message into view.
        try {
            setTimeout(() => {
                try {
                    if (messageDiv && typeof messageDiv.scrollIntoView === 'function') {
                        messageDiv.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
                    } else {
                        smoothScrollToBottom(chatContainer);
                    }
                } catch (e) {
                    smoothScrollToBottom(chatContainer, true);
                }
            }, 30);
        } catch (e) {
            try { chatContainer.scrollTop = chatContainer.scrollHeight; } catch (e2) {}
        }
    }
    return messageDiv;
}

function createLoadingMessage(text = 'Ryo يفكر...') {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message ai-message';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'loading-message';
    contentDiv.innerHTML = text;

    messageDiv.appendChild(contentDiv);

    if (editingMessageData && editingMessageData.messageDiv && editingMessageData.messageDiv.parentNode) {
        editingMessageData.messageDiv.parentNode.insertBefore(messageDiv, editingMessageData.messageDiv.nextSibling);
    } else {
        if (chatContainer) chatContainer.appendChild(messageDiv);
    }

    // Smooth scroll to make loading message visible
    if (chatContainer) {
        try {
            setTimeout(() => {
                try {
                    messageDiv.scrollIntoView({ behavior: 'smooth', block: 'end', inline: 'nearest' });
                } catch (e) {
                    smoothScrollToBottom(chatContainer);
                }
            }, 10);
        } catch (e) {
            try { chatContainer.scrollTop = chatContainer.scrollHeight; } catch (e2) {}
        }
    }

    loadingMessageElement = messageDiv;
    return messageDiv;
}

// ----------------------
// Memory functions (unchanged) ----------------------
async function getUserMemory() {
    if (!db) {
        console.error("Firebase is NOT initialized. Memory features disabled. Check your HTML for required SDK scripts.");
        return [];
    }
    try {
        const docRef = db.collection(MEMORIES_COLLECTION).doc(CURRENT_USER_ID);
        const doc = await docRef.get();
        if (doc.exists) {
            const data = doc.data();
            return Object.values(data).filter(mem => mem.value !== '');
        }
        return [];
    } catch (error) {
        console.error("Error fetching user memory from Firebase:", error);
        return [];
    }
}

async function saveUserMemory(text) {
    if (!db) return "Firebase غير مهيأ، تعذر الحفظ.";

    let memoriesArray = await getUserMemory();

    if (memoriesArray === null) return "Maintenance available";

    let changeDetected = false;
    let memoriesObject = {};

    memoriesArray.forEach(mem => {
        if (mem.key) {
             memoriesObject[mem.key] = mem;
        }
    });

    const findAndSave = (key, regex, title) => {
        const match = text.match(regex);
        if (match && match[2]) {
            const value = match[2].trim();

            if (memoriesObject[key] && memoriesObject[key].value !== value) {
                memoriesObject[key].value = value;
                changeDetected = true;
            } else if (!memoriesObject[key]) {
                memoriesObject[key] = { title: title, value: value, key: key };
                changeDetected = true;
            }
            return true;
        }
        return false;
    };

    findAndSave(
        'name',
        /(اسمي هو|أنا اسمي|ادعى|اسمي)\s*(.*?)/i,
        'اسمك'
    );

    findAndSave(
        'age',
        /(عمري هو|أنا عندي|عمري)\s*([0-9]+\s*(سنة|عام|سنين)|.*?)/i,
        'عمرك'
    );

    findAndSave(
        'hobby',
        /(هوايتي هي|أحب كثيراً|أمارس|هوايتي)\s*(.*?)/i,
        'هوايتك'
    );

    findAndSave(
        'location',
        /(أسكن في|أعيش في|مكاني هو|أقيم في|أسكن|أعيش)\s*(.*?)/i,
        'مكان سكنك'
    );

    const recordMatch = text.match(/(سجل|احفظ|تذكر)\s+أن\s+(.*?)/i);
    if (recordMatch && recordMatch[2]) {
        const info = recordMatch[2].trim();
        const generalKey = 'general_' + Date.now();

        if (!memoriesArray.some(m => m.value === info && m.title === 'معلومة عامة')) {
            memoriesObject[generalKey] = { title: 'معلومة عامة', value: info, key: generalKey };
            changeDetected = true;
        }
    }

    if (changeDetected) {
        try {
            await db.collection(MEMORIES_COLLECTION).doc(CURRENT_USER_ID).set(memoriesObject);
            return "تم تسجيل معلومات مهمة جديدة في الذاكرة بنجاح. (Firebase)";
        } catch (error) {
            console.error("Error saving memory to Firebase:", error);
            return "Maintenance available";
        }
    }

    return "لم يتم العثور على معلومات مهمة لتسجيلها.";
}

async function deleteUserMemory(text) {
    if (!db) return "Firebase غير مهيأ، تعذر الحذف.";

    let memoriesArray = await getUserMemory();
    if (memoriesArray === null) return "Maintenance available";

    let memoriesObject = {};
    memoriesArray.forEach(mem => {
        if (mem.key) memoriesObject[mem.key] = mem;
    });

    let keysToDelete = [];

    if (text.includes('امسح كل شيء') || text.includes('احذف كل معلوماتي') || text.includes('انسَ كل شيء')) {
        try {
            await db.collection(MEMORIES_COLLECTION).doc(CURRENT_USER_ID).delete();
            return "تم مسح جميع معلوماتك من الذاكرة بنجاح. (Firebase) 😇";
        } catch (error) {
            console.error("Error deleting all memory from Firebase:", error);
            return "Maintenance available";
        }
    }

    const deleteKeysMap = {
        'اسم': 'name', 'عمري': 'age', 'هوايتي': 'hobby', 'مكاني': 'location'
    };

    Object.keys(deleteKeysMap).forEach(keyTitle => {
        if (text.includes(`امسح ${keyTitle}`) || text.includes(`احذف ${keyTitle}`) || text.includes(`انسَ ${keyTitle}`)) {
            const key = deleteKeysMap[keyTitle];
            if (memoriesObject[key]) {
                 keysToDelete.push(key);
            }
        }
    });

    const forgetMatch = text.match(/(انسَ|امسح|احذف)\s+أن\s+(.*?)/i);
    if (forgetMatch && forgetMatch[2]) {
         const info = forgetMatch[2].trim();
         const generalMem = memoriesArray.find(m => m.value === info && m.title === 'معلومة عامة');
         if (generalMem) {
             keysToDelete.push(generalMem.key);
         }
    }

    if (keysToDelete.length > 0) {
        try {
            const updateData = {};
            keysToDelete.forEach(key => {
                updateData[key] = firebase.firestore.FieldValue.delete();
            });
            await db.collection(MEMORIES_COLLECTION).doc(CURRENT_USER_ID).update(updateData);
            return "تم مسح بعض المعلومات من الذاكرة بنجاح. (Firebase)";
        } catch (error) {
             console.error("Error deleting specific memory from Firebase:", error);
             return "Maintenance available";
        }
    }

    return "لم يتم رصد طلب حذف معلومات محددة.";
}

async function showUserMemory() {
    let loadingIndicator = createLoadingMessage('Ryo يراجع الذاكرة...');

    const memories = await getUserMemory();

    if (loadingIndicator) {
         try { loadingIndicator.remove(); } catch(e) {}
         loadingIndicator = null;
    }

    if (!memories) {
        const initializationErrorText = `
            ## ❌ خطأ في الذاكرة الدائمة

            عذراً، لا أستطيع الوصول إلى الذاكرة الدائمة (Firebase).

            **الح原因 المؤكد:** لم يتم تحميل مكتبات Firebase SDK في ملف **index.html** قبل ملف **AI.js**.

            **الحل:** يرجى التأكد من أن أسطر \`<script>\` لـ Firebase تأتي قبل أسطر \`<script>\` لـ AI.js.

            لا أستطيع الحفظ أو الجلب بدون اتصال بقاعدة البيانات. 💔
        `;
        createMessageElement(initializationErrorText, 'ai');
        return;
    }

    let responseText = '## 🧠 المعلومات التي أتذكرها عنك:\n\n';

    if (memories.length === 0) {
        responseText += 'لا توجد معلومات مسجلة حالياً في الذاكرة الدائمة. يمكنك أن تخبرني باسمك أو هواياتك لأتذكرها! 😊';
    } else {
        responseText += 'يا صديقي، هذه هي المعلومات التي سجلتها عنك: \n\n';
        responseText += memories.map((mem, index) =>
            `* **${mem.title}**: ${mem.value}`
        ).join('\n');
        responseText += '\n\nأنا سعيد جداً بمعرفتك هذه المعلومات! 💖';
    }

    const aiMessageDiv = createMessageElement(responseText, 'ai');
    if (isVoiceModeActive && aiMessageDiv) {
        speakResponse(responseText);
    }
}

// ----------------------
// Local in-browser fallback using Xenova Transformers
// ----------------------
//
// This function attempts to dynamically import the Xenova transformers library
// and run a small text-generation pipeline locally in the user's browser.
// Pros: avoids external API keys for basic fallback.
// Cons: models are slow/heavy, Arabic quality limited, not suitable for thousands of users.
//
async function runLocalModel(payload, signal, isVisionCall = false, systemInstruction = baseSystemInstruction) {
    if (!window.useLocalModel) {
        throw new Error("Local model fallback is disabled (window.useLocalModel=false).");
    }

    // Build a single prompt from payload.messages (simple concatenation)
    const messages = payload.messages || [];
    let promptParts = [];

    if (systemInstruction) {
        promptParts.push(systemInstruction.trim());
    }

    messages.forEach(m => {
        if (typeof m.content === 'string') {
            const role = (m.role === 'assistant') ? 'Assistant' : ((m.role === 'user') ? 'User' : m.role);
            promptParts.push(`${role}: ${m.content}`);
        } else if (Array.isArray(m.content)) {
            // handle structured content (e.g., vision parts)
            m.content.forEach(part => {
                if (part && part.type === 'text' && part.text) {
                    promptParts.push(`User: ${part.text}`);
                } else if (part && part.type === 'image_url') {
                    promptParts.push(`User: [IMAGE: ${part.image_url?.url || 'data'}]`);
                }
            });
        }
    });

    const prompt = promptParts.join('\n') + '\nAssistant:';

    try {
        // Dynamic import of Xenova transformers (module). This may download the browser runtime.
        const mod = await import('https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.0/dist/transformers.min.js');

        if (!mod || !mod.pipeline) {
            throw new Error("Failed to load transformers pipeline from Xenova.");
        }

        // Get model name and options from window config
        const modelName = window.localModelName || 'Xenova/gpt2';
        const options = window.localModelOptions || { max_new_tokens: 256, temperature: 0.2 };

        // Create text-generation pipeline
        const generator = await mod.pipeline('text-generation', modelName);

        // Run generation. Note: xenova's pipeline doesn't accept AbortSignal in most builds.
        const out = await generator(prompt, {
            max_new_tokens: options.max_new_tokens || 128,
            temperature: (typeof options.temperature !== 'undefined') ? options.temperature : 0.2
        });

        // out is typically an array with generated_text
        const generated_text = (Array.isArray(out) && out[0] && (out[0].generated_text || out[0].generated_text)) ? out[0].generated_text : (out.generated_text || '');

        if (!generated_text) {
            throw new Error("Local model returned no text.");
        }

        return {
            data: {
                choices: [{
                    message: {
                        content: generated_text
                    }
                }]
            },
            source: 'Local'
        };
    } catch (err) {
        // Bubble up
        throw err;
    }
}

// ----------------------
// callMultiAPI and sendMessage (adjusted for link speaking and media prevention)
// ----------------------

function convertOpenAIMessagesToGemini(messages, systemInstruction) {
    let geminiParts = [];

    if (systemInstruction) {
        geminiParts.push({
            role: "user",
            parts: [{ text: `[SYSTEM_INSTRUCTION]: ${systemInstruction}` }]
        });
        geminiParts.push({
            role: "model",
            parts: [{ text: "Acknowledged." }]
        });
    }

    messages.forEach(msg => {
        if (msg.role === 'system') return;

        const role = msg.role === 'assistant' ? 'model' : 'user';
        let parts = [];

        const content = msg.content;

        if (typeof content === 'string') {
            parts.push({ text: content });
        } else if (Array.isArray(content)) {
            content.forEach(part => {
                if (part.type === 'text') {
                    parts.push({ text: part.text });
                } else if (part.type === 'image_url' && part.image_url.url.startsWith('data:')) {
                    const mimeType = part.image_url.url.match(/^data:(.*?);base64/)?.[1];
                    const base64Data = part.image_url.url.split(',')[1];
                    if (mimeType && base64Data) {
                        parts.push({
                            inlineData: {
                                mimeType: mimeType,
                                data: base64Data
                            }
                        });
                    }
                }
            });
        }

        if (parts.length > 0) {
            geminiParts.push({ role, parts });
        }
    });

    return geminiParts;
}

async function callMultiAPI(payload, signal, isVisionCall = false, systemInstruction = baseSystemInstruction) {
    let lastError = null;

    console.log("Starting with Gemini as requested.");
    const geminiModel = isVisionCall ? GEMINI_VISION_MODEL : GEMINI_CHAT_MODEL;
    const geminiEndpoint = `${GEMINI_ENDPOINT}${geminiModel}:generateContent?key=${GEMINI_API_KEY}`;

    const geminiMessages = convertOpenAIMessagesToGemini(payload.messages || [], systemInstruction);
    const geminiPayload = {
        contents: geminiMessages,
        config: {
            temperature: 0.1,
        }
    };

    try {
        const response = await fetch(geminiEndpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(geminiPayload),
            signal: signal
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`مفيش خدمة حاليا ${response.status} استنى يوم👻🤍: ${errorBody.substring(0, 100)}`);
        }

        const data = await response.json();

        const geminiResponse = {
            choices: [{
                message: {
                    content: data.candidates?.[0]?.content?.parts?.[0]?.text || "عذراً، لم أتلق إجابة من Gemini."
                }
            }]
        };

        return { data: geminiResponse, source: 'Gemini' };

    } catch (error) {
        if (error.name === 'AbortError') throw error;
        lastError = error;
        console.warn("Gemini failed. Falling over to OpenAI. Error:", error.message);
    }


    console.log("Falling over to OpenAI.");
    const openaiModel = isVisionCall ? OPENAI_VISION_MODEL : OPENAI_CHAT_MODEL;
    const openaiPayload = { ...payload, model: openaiModel };

    const openaiSystemMessagePresent = openaiPayload.messages && openaiPayload.messages.some(msg => msg.role === 'system');
    if (!openaiSystemMessagePresent) {
        openaiPayload.messages = openaiPayload.messages || [];
        openaiPayload.messages.unshift({ role: 'system', content: systemInstruction });
    }

    try {
        const response = await fetch(OPENAI_ENDPOINT, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(openaiPayload),
            signal: signal
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`مفيش خدمة ${response.status} استنى يوم🤍👻: ${errorBody.substring(0, 100)}`);
        }

        return { data: await response.json(), source: 'OpenAI' };

    } catch (error) {
        if (error.name === 'AbortError') throw error;

        lastError = error;
        console.warn("error", error.message);
    }

    console.log("Falling over to Groq keys.");
    // Try Groq keys round-robin
    for (let i = 0; i < API_KEYS_POOL.length; i++) {
        const apiKey = API_KEYS_POOL[currentAPIIndex] || API_KEYS_POOL[0];
        const groqPayload = {
            ...payload,
            model: isVisionCall ? VISION_MODEL : CHAT_MODEL
        };

        const systemMessagePresent = groqPayload.messages && groqPayload.messages.some(msg => msg.role === 'system');
        if (!systemMessagePresent) {
            groqPayload.messages = groqPayload.messages || [];
            groqPayload.messages.unshift({ role: 'system', content: systemInstruction });
        }

        try {
            const response = await fetch(GROQ_ENDPOINT, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(groqPayload),
                signal: signal
            });

            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(`مفيش خدمة حاليا ${response.status} استنى يوم Index ${currentAPIIndex}: ${errorBody.substring(0, 100)}`);
            }

            return { data: await response.json(), source: 'Groq' };

        } catch (error) {
            if (error.name === 'AbortError') throw error;

            lastError = error;
            console.warn(`لا${i + 1} توجد خدمة في الوقت الحالي${currentAPIIndex}. يوجد صيانة `, error.message);

            currentAPIIndex = (currentAPIIndex + 1) % API_KEYS_POOL.length;
        }
    }

    console.log("لا يوجد خدمة حاليا👻");
    const fireworksModel = isVisionCall ? FIREWORKS_VISION_MODEL : FIREWORKS_CHAT_MODEL;
    const fireworksPayload = { ...payload, model: fireworksModel };

    const fireworksSystemMessagePresent = fireworksPayload.messages && fireworksPayload.messages.some(msg => msg.role === 'system');
    if (!fireworksSystemMessagePresent) {
        fireworksPayload.messages = fireworksPayload.messages || [];
        fireworksPayload.messages.unshift({ role: 'system', content: systemInstruction });
    }

    try {
        const response = await fetch(FIREWORKS_ENDPOINT, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${FIREWORKS_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(fireworksPayload),
            signal: signal
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`مفيش خدمة حاليا ${response.status} استنى يوم👻🤍: ${errorBody.substring(0, 100)}`);
        }

        return { data: await response.json(), source: 'Fireworks AI' };

    } catch (error) {
        if (error.name === 'AbortError') throw error;

        lastError = error;
        console.warn("استنى يوم وارجع في صيانة👻🤍:", error.message);

        // FINAL FALLBACK: try local in-browser model (Xenova) if enabled
        if (window.useLocalModel) {
            try {
                console.log("Attempting local in-browser model fallback (Xenova).");
                return await runLocalModel(payload, signal, isVisionCall, systemInstruction);
            } catch (localErr) {
                lastError = localErr;
                console.error("Local in-browser model failed:", localErr);
            }
        }

        console.error("Fireworks AI failed. All services are down. Error:", error.message);

        throw new Error(`All API services failed (OpenAI, Groq, Fireworks AI, Gemini${window.useLocalModel ? ', Local' : ''}). Last error: ${lastError ? lastError.message : 'Unknown error'}`);
    }
}

function setSendingUI(loading) {
    isAILoading = loading;

    const shouldShowSendButton = textInput && (textInput.value.trim() || attachedFiles.length > 0);

    if (loading) {
        if (sendButton) sendButton.style.pointerEvents = 'none';
        if (voiceButton) voiceButton.style.pointerEvents = 'none';
    } else {
        if (sendButton) sendButton.style.pointerEvents = shouldShowSendButton ? 'auto' : 'none';
        if (voiceButton) voiceButton.style.pointerEvents = shouldShowSendButton ? 'none' : 'auto';

        if (editingMessageData) {
            if (sendButton) sendButton.innerHTML = '<span class="material-icons-outlined">done</span>';
        } else {
            if (sendButton) sendButton.innerHTML = '<span class="material-icons-outlined">send</span>';
        }
    }

    if (shouldShowSendButton) {
        if (sendButton) sendButton.style.display = 'flex';
        if (voiceButton) voiceButton.style.display = 'none';
    } else {
        if (sendButton) sendButton.style.display = 'none';
        if (voiceButton) voiceButton.style.display = 'flex';
    }

}

function fileToGenerativePart(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (!reader.result || typeof reader.result !== 'string' || !reader.result.includes(',')) {
                reject(new Error("File reading failed or result is not a Data URL."));
                return;
            }
            const base64Data = reader.result.split(',')[1];
            resolve(base64Data);
        };
        reader.onerror = (error) => {
            reject(new Error(`Error reading file: ${error?.target?.error?.code || error}`));
        };
        reader.readAsDataURL(file);
    });
}

async function analyzeImageWithVisionModel(imageFile, userPrompt) {
    if (typeof imageFile === 'string' && imageFile.startsWith('data:')) {
        return analyzeImageDataURLWithVisionModel(imageFile, 'image.jpg', userPrompt);
    }

    const base64Image = await fileToGenerativePart(imageFile);
    const promptText = userPrompt || "صف هذه الصورة.";

    const visionMessageContent = [
        { type: "text", text: promptText },
        { type: "image_url", image_url: { url: `data:${imageFile.type};base64,${base64Image}` } }
    ];

    const payload = {
        model: VISION_MODEL,
        messages: [{ role: "user", content: visionMessageContent }],
        stream: false
    };

    try {
        const result = await callMultiAPI(payload, controller ? controller.signal : undefined, true);

        const analysisText = result.data.choices?.[0]?.message?.content || "Maintenance available";

        return analysisText;
    } catch (error) {
        if (error.name === 'AbortError') throw error;
        return `خطأ: ${error.message}`;
    }
}

async function processImage(imageFile, userPrompt) {
    const fileName = imageFile.name;

    try {
        const analysisText = await analyzeImageWithVisionModel(imageFile, userPrompt);
        const historyDescription = `**[وصف الصورة (${fileName})]**:\n${analysisText}`;
        return { content: { type: "text", text: historyDescription }, historyDescription: historyDescription };
    } catch (error) {
        if (error.name === 'AbortError') throw error;
        return { content: { type: "text", text: `فشل تحليل الصورة (${fileName}): ${error.message}` }, historyDescription: `فشل تحليل الصورة (${fileName})` };
    }
}

// Updated processFile to handle video files (extract frame and analyze) and other files safely
async function processFile(file) {
    const fileName = file.name;
    const fileType = file.type || 'unknown';

    // handle video: extract representative frame and analyze it
    if (fileType.startsWith('video')) {
        try {
            const frameDataUrl = await extractFrameFromVideo(file);
            const promptText = `هذا فيديو اسمه "${fileName}". أرفقت لقطة من الإطار الأول. الرجاء وصف محتوى هذه اللقطة بإيجاز وبالعربية الفصحى.`;
            const analysis = await analyzeImageDataURLWithVisionModel(frameDataUrl, `${fileName}_frame.jpg`, promptText);

            const historyDescription = `**[فيديو (${fileName}) - لقطة من الإطار الأول]**:\n${analysis}`;
            return { content: { type: "text", text: historyDescription }, historyDescription: historyDescription };
        } catch (err) {
            const resultMessage = `**[فيديو (${fileName})]**: تم رفع فيديو (لم يتمكن النظام من استخراج إطار للتحليل تلقائيًا). يمكنك طلب "حلل هذا الفيديو" أو تحميل لقطة صورة.`;
            return { content: { type: "text", text: resultMessage }, historyDescription: resultMessage };
        }
    }

    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = (e) => {
            try {
                let fileContent = fileType.match(/text|json|javascript|html|css/) ? e.target.result : `[محتوى ثنائي لملف من نوع: ${fileType}]`;
                let contentSnippet = '';
                if (typeof fileContent === 'string') {
                    contentSnippet = fileContent.substring(0, 2000);
                } else {
                    contentSnippet = fileContent.toString().substring(0, 2000);
                }
                const resultMessage = `**[ملف (${fileName})]**:\n\`\`\`\n${contentSnippet}\n\`\`\``;
                resolve({ content: { type: "text", text: resultMessage }, historyDescription: resultMessage });
            } catch (err) {
                reject(err);
            }
        };
        reader.onerror = (error) => reject(error);

        if (fileType.match(/text|json|javascript|html|css/)) {
            reader.readAsText(file);
        } else {
             reader.readAsArrayBuffer(file);
        }
    });
}

async function sendMessage() {
    if (isAILoading) return;

    if (isListening) stopVoiceMode(false);
    if (isSpeaking && synthesis) try { synthesis.cancel(); } catch (e) {}

    const text = textInput ? textInput.value.trim() : '';
    const attachments = attachedFiles.map(item => item.file).filter(file => file);

    if (!text && attachments.length === 0 && !editingMessageData) return;

    if (welcomeScreen && welcomeScreen.style.display !== 'none') welcomeScreen.style.display = 'none';

    hideAllEditButtons();
    setSendingUI(true);
    abortTyping = false;

    try {
        if (controller) {
            try { controller.abort(); } catch (e) { /* ignore */ }
            controller = null;
        }
    } catch (err) {
        console.warn("Failed to abort previous controller:", err);
    }

    controller = new AbortController();
    const signal = controller.signal;

    const userFilesData = attachedFiles.map(item => ({
        url: item.url,
        name: item.name,
        mimeType: item.mimeType,
        file: item.file
    }));

    let userMessageDiv;
    try {
        if (editingMessageData) {
            userMessageDiv = editingMessageData.messageDiv;
            const contentDiv = userMessageDiv.querySelector('.user-message-content');

            let formattedText = (text || '').replace(/`([^`]+)`/g, '<code>$1</code>');
            formattedText = formattedText.replace(/\n/g, '<br>');

            if (contentDiv) contentDiv.innerHTML = formattedText;
        } else {
            userMessageDiv = await createMessageElement(text, 'user', userFilesData);
        }
    } catch (err) {
        console.error("Failed to create user message element:", err);
    }

    if (!editingMessageData) {
        attachedFiles.forEach(fileData => {
            try { URL.revokeObjectURL(fileData.url); } catch (e) {}
        });
        attachedFiles = [];
        if (attachmentsPreview) attachmentsPreview.innerHTML = '';
    }

    if (textInput) {
        textInput.value = '';
        textInput.style.height = 'auto';
    }
    if (sendButton) sendButton.style.pointerEvents = 'none';

    const isMemoryRelated = (text || '').match(/(اسمي|عمري|هوايتي|تذكر|احفظ|سجل|انسَ|امسح|احذف)/i);
    let memoryOperationDone = false;

    try {
        if (isMemoryRelated) {
            if (text.match(/(سجل|احفظ|تذكر)/i)) {
                try { await saveUserMemory(text); } catch (err) { console.error("saveUserMemory error:", err); }
                memoryOperationDone = true;
            }
            if (text.match(/(امسح|احذف|انسَ)/i)) {
                try { await deleteUserMemory(text); } catch (err) { console.error("deleteUserMemory error:", err); }
                memoryOperationDone = true;
            }

            if (memoryOperationDone) {
                let tempIndicator = createLoadingMessage('Ryo يربط الأفكار… 🔗');
                await new Promise(resolve => setTimeout(resolve, 500));
                if(tempIndicator) tempIndicator.remove();
            }
        }

        const showMemoryKeywords = /قولي المعلومات المتسجله عندك|قولي ذاكرتك|ايه المعلومات المسجله عندك|ماذا تعرف عني|ما هي معلوماتي المسجلة|اذكرلي معلوماتي|قولي اسمي|قولي عمري|ايش تعرف عني|المعلومات المسجلة/i;
        if (text.match(showMemoryKeywords)) {
            await showUserMemory();
            setSendingUI(false);
            if(editingMessageData) exitEditMode();
            return;
        }

        let historyParts = [];
        let finalUserPrompt = text;
        let hasAttachments = attachments.length > 0 && !editingMessageData;

        if (hasAttachments) {
             loadingMessageElement = createLoadingMessage('Ryo يحلل المرفقات...');
        }

        if (hasAttachments) {
            try {
                const analysisPromises = attachments.map(file => {
                    if (file.type.startsWith('image')) return processImage(file, text);
                    return processFile(file);
                });

                const analysisResults = await Promise.all(analysisPromises);
                analysisResults.forEach(part => historyParts.push(part.historyDescription));

                if (loadingMessageElement) {
                    try { loadingMessageElement.querySelector('.loading-message').innerHTML = 'Ryo يفكر...'; } catch (e) {}
                }

            } catch (error) {
                if (error.name === 'AbortError') throw error;

                if (loadingMessageElement) {
                    try { loadingMessageElement.remove(); } catch(e) {}
                    loadingMessageElement = null;
                }
                setSendingUI(false);
                return;
            }
        }


        let textToSaveInHistory = '';
        let textToSendToModel = finalUserPrompt;

        const userMemories = await getUserMemory();
        let finalSystemInstruction = baseSystemInstruction.trim();

        if (userMemories && userMemories.length > 0) {
            let memoryText = userMemories.map(m => `* **${m.title}**: ${m.value}`).join('\n');
            finalSystemInstruction += `\n\n[**سياق الذاكرة**]: هذه هي المعلومات التي يتذكرها Ryo عن المستخدم:\n${memoryText}`;

            const userName = userMemories.find(m => m.key === 'name')?.value;
            if (userName) {
                finalSystemInstruction += `\n\n[**تعليمات المخاطبة**]: خاطب المستخدم باسمه **${userName}** بشكل مباشر وودود بدلاً من "صديقي".`;
            }
        }

        const languageGuardPrompt = "[**تنبيه صارم**]: أجب فقط باللغة العربية الفصحى. لا تستخدم أي لغة أخرى تحت أي ظرف. \n\n";

        if (historyParts.length > 0) {
            textToSaveInHistory += '**[تحليل المرفقات المخفي]**\n\n' + historyParts.join('\n\n---\n\n') + '\n\n---\n\n';
            textToSendToModel = historyParts.join('\n\n') + '\n\n' + (finalUserPrompt || "حلل المرفقات.");
        }
        textToSaveInHistory += `**[نص المستخدم الأصلي]**\n\n${finalUserPrompt}`;

        textToSendToModel = languageGuardPrompt + textToSendToModel;

        const cleanTextForUI = finalUserPrompt || "مرفقات فقط.";
        const userMessageContentDiv = userMessageDiv ? userMessageDiv.querySelector('.user-message-content') : null;
        if (userMessageContentDiv) {
            userMessageContentDiv.setAttribute('data-original-text', textToSaveInHistory);
            userMessageContentDiv.innerHTML = cleanTextForUI.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\n/g, '<br>');
        }

        const historyMessages = [];

        if (editingMessageData) {
            const userMessageDivLocal = editingMessageData.messageDiv;
            const msgIndex = currentChatHistory.findIndex(msg => msg.id === editingMessageData.msgId);

            if (msgIndex > -1) {
                currentChatHistory[msgIndex].content = textToSaveInHistory;

                const numberOfMessagesToDelete = currentChatHistory.length - (msgIndex + 1);
                if (numberOfMessagesToDelete > 0) {
                    currentChatHistory.splice(msgIndex + 1, numberOfMessagesToDelete);
                }

                let nextMessage = userMessageDivLocal.nextElementSibling;
                while(nextMessage) {
                    const tempNext = nextMessage.nextElementSibling;
                    try { nextMessage.remove(); } catch(e) {}
                    nextMessage = tempNext;
                }
            }
        } else {
            currentChatHistory.push({ role: 'user', content: textToSaveInHistory, id: userMessageDiv ? userMessageDiv.id : (`msg-${Date.now()}`) });
        }


        const historyLimit = saveChats ? 0 : Math.max(0, currentChatHistory.length - 4);

        currentChatHistory.slice(historyLimit).forEach(msg => {
            if (msg.role !== 'system') {
                let finalContent = msg.content;

                if (msg.role === 'user') {
                    const originalPrompt = getCleanUserText(msg.content);
                    const analysisMatch = msg.content.match(/\*\*\[تحليل المرفقات المخفي\]\*\*[\s\S]*\-\-\-\n\n/i);

                    if (analysisMatch) {
                        const analysisPart = analysisMatch[0].replace(/\*\*\[تحليل المرفقات المخفي\]\*\*|\n\n\-\-\-\n\n/gi, '').trim();
                        finalContent = analysisPart + '\n\n' + originalPrompt;
                    } else {
                         finalContent = originalPrompt;
                    }

                    finalContent = languageGuardPrompt + finalContent;
                }

                historyMessages.push({ role: msg.role === 'assistant' ? 'assistant' : 'user', content: finalContent });
            }
        });

        const messages = historyMessages;

        if (!loadingMessageElement) {
            loadingMessageElement = createLoadingMessage('Ryo يفكر...');
        }

        const payload = {
            model: CHAT_MODEL,
            messages: messages,
            stream: false,
            temperature: 0.1
        };

        try {
            const result = await callMultiAPI(payload, signal, false, finalSystemInstruction);
            const aiResponseText = result.data.choices?.[0]?.message?.content || "عذراً، لم أتلق إجابة.";

            const finalResponse = aiResponseText;

            if (loadingMessageElement) {
                try { loadingMessageElement.remove(); } catch(e) {}
                loadingMessageElement = null;
            }

            if (finalResponse) {
                // Detect media/link in response
                const parsedMedia = parseMediaFromText(finalResponse);

                if (parsedMedia && parsedMedia.type !== 'error') {
                    // If parsedMedia is data_url or frames -> blocked earlier in insertMediaMessage
                    const aiMessageDiv = await insertMediaMessage(parsedMedia, finalResponse);

                    // Store a compact representation in history (either the URL or a short note)
                    const historyContent = parsedMedia.format === 'url' ? (parsedMedia.url || finalResponse) : (`[ملف وسائط محظور: ${parsedMedia.type}]`);

                    if (editingMessageData) {
                         const userMsgIndex = currentChatHistory.findIndex(msg => msg.id === editingMessageData.msgId);
                         if (userMsgIndex > -1) {
                             currentChatHistory.splice(userMsgIndex + 1, 0, { role: 'assistant', content: historyContent, id: aiMessageDiv ? aiMessageDiv.id : (`msg-${Date.now()}`) });
                         }
                    } else {
                         currentChatHistory.push({ role: 'assistant', content: historyContent, id: aiMessageDiv ? aiMessageDiv.id : (`msg-${Date.now()}`) });
                    }

                    if (saveChats) saveChat(textToSaveInHistory);

                } else if (parsedMedia && parsedMedia.type === 'error') {
                    const aiMessageDiv = createMessageElement(`**خطأ أثناء الإنشاء:** ${escapeHtml(parsedMedia.message)}`, 'ai', [], null, false);
                    if (editingMessageData) {
                         const userMsgIndex = currentChatHistory.findIndex(msg => msg.id === editingMessageData.msgId);
                         if (userMsgIndex > -1) {
                             currentChatHistory.splice(userMsgIndex + 1, 0, { role: 'assistant', content: `ERROR: ${parsedMedia.message}`, id: aiMessageDiv.id });
                         }
                    } else {
                         currentChatHistory.push({ role: 'assistant', content: `ERROR: ${parsedMedia.message}`, id: aiMessageDiv.id });
                    }
                    if (saveChats) saveChat(textToSaveInHistory);
                } else {
                    // Normal text response (no detectable media)
                    const aiMessageDiv = createMessageElement(finalResponse, 'ai', [], null, false);

                    // If the response contains a URL, speak a short notification
                    const containsUrl = typeof finalResponse === 'string' && /(https?:\/\/[^\s'"]+)/i.test(finalResponse);
                    if (containsUrl) {
                        try { speakResponse('أرسلت رابطًا في الرسالة أعلاه. افتحه بالضغط على الرابط.'); } catch (e) {}
                    }

                    if (editingMessageData) {
                         const userMsgIndex = currentChatHistory.findIndex(msg => msg.id === editingMessageData.msgId);
                         if (userMsgIndex > -1) {
                             currentChatHistory.splice(userMsgIndex + 1, 0, { role: 'assistant', content: finalResponse, id: aiMessageDiv.id });
                         }
                    } else {
                         currentChatHistory.push({ role: 'assistant', content: finalResponse, id: aiMessageDiv.id });
                    }

                    if (saveChats) saveChat(textToSaveInHistory);

                    if (isVoiceModeActive && aiMessageDiv) {
                        speakingMessage = finalResponse;
                        speakResponse(finalResponse);
                    }
                }
            }

        } catch (error) {
            if (error.name === 'AbortError') {
                console.warn("Request aborted by user or new request.");
            } else {
                console.error("AI API Error:", error);
                if (loadingMessageElement) {
                    try { loadingMessageElement.remove(); } catch(e) {}
                    loadingMessageElement = null;
                }
                createMessageElement(`عذراً،  : **${escapeHtml(error.message || 'Unknown error')}**يوجد صيا��ة في الوقت الحالي `, 'ai');
            }
        } finally {
            setSendingUI(false);
            if (loadingMessageElement) {
                try { loadingMessageElement.remove(); } catch (e) {}
                loadingMessageElement = null;
            }

            try {
                controller = null;
            } catch (e) {}

            if (!editingMessageData) {
                userFilesData.forEach(fileData => {
                    try { URL.revokeObjectURL(fileData.url); } catch (e) {}
                });
            }

            if (editingMessageData) exitEditMode();
        }
    } catch (err) {
        console.error("sendMessage unexpected error:", err);
        setSendingUI(false);
        if (loadingMessageElement) {
            try { loadingMessageElement.remove(); } catch(e) {}
            loadingMessageElement = null;
        }
        try { controller = null; } catch (e) {}
    }
}

// ----------------------
// Chats persistence & UI (unchanged except scroll improvements) ----------------------

function loadChatsFromLocalStorage() {
    const chats = (function(){ try { return localStorage.getItem('userChats'); } catch (e) { return null; } })();
    if (!chats) return {};
    try {
        return JSON.parse(chats);
    } catch (err) {
        console.error("Failed parsing userChats from localStorage:", err);
        try { localStorage.removeItem('userChats'); } catch (e) {}
        return {};
    }
}

function saveChatsToLocalStorage(chats) {
    try {
        localStorage.setItem('userChats', JSON.stringify(chats));
    } catch (err) {
        console.error("Failed saving chats to localStorage:", err);
    }
}

function saveChat(userMsg) {
    if (!saveChats) return;
    const chats = loadChatsFromLocalStorage();
    const now = Date.now();

    let cleanMsg = getCleanUserText(userMsg);

    if (!currentChatId || !chats[currentChatId]) {
        currentChatId = now;
        let cleanTitle = cleanMsg.trim();
        if (cleanTitle.length === 0) {
            cleanTitle = userMsg.includes('**[وصف الصورة') ? 'محادثة صور' : 'محادثة جديدة';
        }
        const initialTitle = cleanTitle.substring(0, 40).trim().replace(/\n/g, ' ') + (cleanTitle.length > 40 ? '...' : '');

        chats[currentChatId] = {
            id: currentChatId,
            title: initialTitle,
            history: currentChatHistory,
            timestamp: now
        };
    } else {
        chats[currentChatId].history = currentChatHistory;
        chats[currentChatId].timestamp = now;
    }

    saveChatsToLocalStorage(chats);
    loadChatsList();
}

function loadChatsList() {
    if (!chatList) {
        chatList = document.getElementById('chatList');
        if (!chatList) return;
    }
    chatList.innerHTML = '';
    const chats = loadChatsFromLocalStorage();

    let sortedChats = Object.values(chats).sort((a, b) => b.timestamp - a.timestamp);

    if (deleteAllChatsButton) {
        if (Object.keys(chats).length > 0) {
            deleteAllChatsButton.style.display = 'block';
        } else {
            deleteAllChatsButton.style.display = 'none';
        }
    }

    sortedChats.forEach(chat => {
        const chatItem = document.createElement('div');
        chatItem.className = 'chat-list-item';
        chatItem.setAttribute('data-chat-id', chat.id);
        if (currentChatId && currentChatId == chat.id) {
            chatItem.classList.add('active-chat-item');
        }

        const titleSpan = document.createElement('span');
        titleSpan.className = 'chat-list-title';
        titleSpan.textContent = chat.title;

        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-chat-button';
        deleteButton.textContent = 'حذف';

        chatItem.addEventListener('click', (e) => {
            if (chatItem.classList.contains('deletable')) {
                chatItem.classList.remove('deletable');
                return;
            }
            e.stopPropagation();
            document.querySelectorAll('.chat-list-item').forEach(item => item.classList.remove('deletable'));
            loadChatHistory(chat.id);
            if (menuOverlay) menuOverlay.classList.remove('open');
        });

        deleteButton.addEventListener('click', (e) => {
            e.stopPropagation();
            deleteChat(chat.id);
        });

        chatItem.appendChild(titleSpan);
        chatItem.appendChild(deleteButton);

        let pressTimer;
        chatItem.addEventListener('touchstart', (e) => {
            if (e.target.closest('.delete-chat-button')) return;
            e.stopPropagation();
            document.querySelectorAll('.chat-list-item').forEach(item => item.classList.remove('deletable'));
            pressTimer = setTimeout(() => {
                chatItem.classList.add('deletable');
            }, 800);
        });
        chatItem.addEventListener('touchend', () => { clearTimeout(pressTimer); });
        chatItem.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            document.querySelectorAll('.chat-list-item').forEach(item => item.classList.remove('deletable'));
            chatItem.classList.add('deletable');
        });

        chatList.appendChild(chatItem);
    });
}

function loadChatHistory(id) {
    const chats = loadChatsFromLocalStorage();
    const chat = chats[id];

    if (chat) {
        currentChatId = id;
        currentChatHistory = Array.isArray(chat.history) ? chat.history : [];
        if (chatContainer) chatContainer.innerHTML = '';
        if (welcomeScreen) {
            if (chatContainer && welcomeScreen.parentNode !== chatContainer) {
                // ensure welcomeScreen appended only if needed
            }
        }

        if (chat.history && chat.history.length > 0 && welcomeScreen) {
            welcomeScreen.style.display = 'none';
        }

        (chat.history || []).forEach(msg => {
            if (msg.role !== 'system') {
                // When loading history we may have stored plain URLs or prepared HTML fragments.
                // For safety: if the stored msg.content looks like a full HTML snippet we set isImmediateDisplay true,
                // otherwise we allow formatResponseWithCodeBlocks to convert URLs to anchors.
                const isHtml = looksLikeHtml(msg.content);
                createMessageElement(msg.content, msg.role === 'assistant' ? 'ai' : 'user', [], msg.id || null, isHtml);
            }
        });

        // After rendering history, smooth-scroll to bottom so the latest messages are visible
        if (chatContainer) {
            setTimeout(() => {
                smoothScrollToBottom(chatContainer);
            }, 40);
        }

        if (menuOverlay) menuOverlay.classList.remove('open');
        loadChatsList();
    }
}

function deleteChat(chatId) {
    if (!confirm("هل أنت متأكد من حذف هذه المحادثة؟")) return;

    const chats = loadChatsFromLocalStorage();
    delete chats[chatId];
    saveChatsToLocalStorage(chats);
    loadChatsList();

    if (currentChatId == chatId) {
        startNewChat();
    }

    console.log("Chat history deleted. Permanent memory (ryo_memories) is NOT affected.");
}

function deleteAllChats() {
    if (!confirm("هل أنت متأكد من حذف جميع المحادثات؟ لن يتم حذف معلوماتك الشخصية المسجلة (مثل اسمك وهواياتك). لا يمكن التراجع عن هذا الإجراء.")) return;
    try { localStorage.removeItem('userChats'); } catch (e) {}
    startNewChat();
}

function startNewChat() {
    if (chatContainer) {
        chatContainer.innerHTML = '';
        if (welcomeScreen) chatContainer.appendChild(welcomeScreen);
    }
    if (welcomeScreen) welcomeScreen.style.display = 'flex';
    if (menuOverlay) menuOverlay.classList.remove('open');
    if (attachmentsPreview) attachmentsPreview.innerHTML = '';
    attachedFiles = [];
    if (textInput) {
        textInput.value = '';
        textInput.style.height = 'auto';
    }

    if (sendButton) sendButton.style.pointerEvents = 'none';

    document.querySelectorAll('.chat-list-item').forEach(item => {
        item.classList.remove('active-chat-item');
        item.classList.remove('deletable');
    });
    currentChatId = null;
    currentChatHistory = [];
    if (editingMessageData) exitEditMode();
    initSaveToggleState();
}

function initSaveToggleState() {
    if (!saveToggleButton || !saveToggleIcon) return;
    if (saveChats) {
        saveToggleButton.classList.remove('saving-disabled');
        saveToggleIcon.textContent = 'bookmark_added';

        if (saveToggleCheck) saveToggleCheck.style.display = 'none';

        if (chatContainerTemporaryMessage) chatContainerTemporaryMessage.style.display = 'none';
        if (menuTemporaryMessage) menuTemporaryMessage.style.display = 'none';

        if (currentChatId) {
             loadChatsList();
        }
    } else {
        saveToggleButton.classList.add('saving-disabled');
        saveToggleIcon.textContent = 'bookmark_remove';

        if (saveToggleCheck) saveToggleCheck.style.display = 'none';

        if (chatContainerTemporaryMessage) chatContainerTemporaryMessage.style.display = 'flex';
        if (menuTemporaryMessage) menuTemporaryMessage.style.display = 'block';
    }
}

if (saveToggleButton) {
    saveToggleButton.addEventListener('click', () => {
        saveChats = !saveChats;
        window.saveChats = saveChats;
        try { localStorage.setItem('saveChats', saveChats); } catch (e) {}
        initSaveToggleState();

        if (saveChats && !currentChatId && currentChatHistory.length > 0) {
             saveChat(currentChatHistory[currentChatHistory.length - 2]?.content || 'محادثة جديدة');
        } else if (!saveChats) {
            document.querySelectorAll('.chat-list-item').forEach(item => item.classList.remove('active-chat-item'));
        }
    });
}

if (newChatPencilButton) {
    newChatPencilButton.addEventListener('click', startNewChat);
}

if (menuButton) {
    menuButton.addEventListener('click', () => {
        if (menuOverlay) menuOverlay.classList.toggle('open');
        if (menuOverlay && menuOverlay.classList.contains('open')) {
            loadChatsList();
        }
    });
}
if (menuOverlay) {
    menuOverlay.addEventListener('click', (e) => {
        if (e.target === menuOverlay) {
            menuOverlay.classList.remove('open');
        }
    });
}

if (newChatButton) {
    newChatButton.addEventListener('click', startNewChat);
}

if (deleteAllChatsButton) {
    deleteAllChatsButton.addEventListener('click', deleteAllChats);
}

// PROMPT BUTTONS:
// Instead of auto-sending preset prompts immediately, open the suggestions UI (so the user picks one).
document.querySelectorAll('.prompt-button').forEach(button => {
    button.addEventListener('click', () => {
        try {
            const promptKey = button.getAttribute('data-prompt-key');
            if (typeof showSuggestions === 'function') {
                showSuggestions(promptKey);
            } else {
                const textAttr = button.getAttribute('data-prompt-text') || button.getAttribute('data-prompt') || '';
                if (textInput) {
                    textInput.value = textAttr;
                    textInput.dispatchEvent(new Event('input'));
                }
            }
        } catch (err) {
            console.error("prompt-button click handler failed:", err);
        }
    });
});

document.querySelectorAll('.prompt-button').forEach(button => {
    button.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            button.click();
        }
    });
});

function fadeOutAttachmentOptions() {
    if (!attachmentOptions) return;
    attachmentOptions.classList.remove('visible');
}

if (attachmentButton) {
    attachmentButton.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!attachmentOptions) return;
        attachmentOptions.classList.toggle('visible');
    });
}

document.addEventListener('click', (e) => {
    try {
        if (attachmentButton && attachmentOptions && !attachmentButton.contains(e.target) && !attachmentOptions.contains(e.target)) {
            fadeOutAttachmentOptions();
        }

        if (!e.target.closest('.edit-controls')) {
            hideAllEditButtons();
        }
    } catch (err) {
        console.error("Global click handler error:", err);
    }
});

if (chatContainer) {
    chatContainer.addEventListener('scroll', () => {
        hideAllEditButtons();
    });
}

function handleFileInputs(inputElement) {
    if (!inputElement || !inputElement.files) return;
    const files = Array.from(inputElement.files);

    files.forEach(file => {
        const newFile = {
            file: file,
            name: file.name,
            mimeType: file.type,
            url: URL.createObjectURL(file),
            size: file.size
        };

        if (attachedFiles.some(f => f.name === file.name && f.size === file.size)) return;

        attachedFiles.push(newFile);

        const filePreview = document.createElement('div');
        filePreview.classList.add('attachment-item');
        filePreview.file = file;

        const removeBtn = document.createElement('span');
        removeBtn.classList.add('material-icons-outlined');
        removeBtn.textContent = 'close';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.marginLeft = '5px';
        removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            attachedFiles = attachedFiles.filter(f => !(f.name === file.name && f.size === file.size));
            try { URL.revokeObjectURL(newFile.url); } catch (e) {}
            try { filePreview.remove(); } catch(e) {}

            if (attachedFiles.length === 0 && textInput && !textInput.value.trim()) {
                if (sendButton) sendButton.style.pointerEvents = 'none';
                if (sendButton) sendButton.style.display = 'none';
                if (voiceButton) voiceButton.style.display = 'flex';
            }
        });

        if (file.type.startsWith('image')) {
            const img = document.createElement('img');
            img.src = newFile.url;
            img.onload = () => {};
            filePreview.appendChild(img);
            filePreview.classList.add('image-attachment-preview');
        } else if (file.type.startsWith('video')) {
            const vid = document.createElement('video');
            vid.src = newFile.url;
            vid.controls = true;
            vid.preload = 'metadata';
            vid.classList.add('video-attachment-preview');
            vid.style.maxWidth = '160px';
            vid.style.maxHeight = '120px';
            filePreview.appendChild(vid);
        } else {
            let fileType = file.name.split('.').pop().toUpperCase() || 'FILE';
            const displayType = fileType.substring(0, 4);
            filePreview.innerHTML = '';

            const iconWrapper = document.createElement('div');
            iconWrapper.classList.add('custom-file-icon-preview');
            iconWrapper.innerHTML = `
                <div class="file-icon-wrapper-preview">
                    <span class="file-fold-corner-preview"></span>
                    <span class="file-type-text-preview">${displayType}</span>
                </div>
            `;
            filePreview.appendChild(iconWrapper);
        }

        filePreview.appendChild(removeBtn);
        if (attachmentsPreview) attachmentsPreview.appendChild(filePreview);

        if (sendButton) sendButton.style.pointerEvents = 'auto';
        if (sendButton) sendButton.style.display = 'flex';
        if (voiceButton) voiceButton.style.display = 'none';
    });
    inputElement.value = null;
}

if (document.getElementById('photoOption')) {
    document.getElementById('photoOption').addEventListener('click', () => {
        fadeOutAttachmentOptions();
        setTimeout(() => photoInput && photoInput.click(), 400);
    });
}
if (photoInput) photoInput.addEventListener('change', () => handleFileInputs(photoInput));

if (document.getElementById('fileOption')) {
    document.getElementById('fileOption').addEventListener('click', () => {
        fadeOutAttachmentOptions();
        setTimeout(() => {
            if (fileInput) {
                fileInput.accept = '*';
                fileInput.click();
            }
        }, 400);
    });
}
if (fileInput) fileInput.addEventListener('change', () => handleFileInputs(fileInput));

if (document.getElementById('cameraOption')) {
    document.getElementById('cameraOption').addEventListener('click', () => {
        fadeOutAttachmentOptions();
        setTimeout(() => {
            if (!cameraInput) return;
            cameraInput.accept = "image/*";
            cameraInput.capture = "camera";
            cameraInput.click();
        }, 400);
    });
}
if (cameraInput) cameraInput.addEventListener('change', () => handleFileInputs(cameraInput));

if (document.getElementById('videoOption')) {
    document.getElementById('videoOption').addEventListener('click', () => {
        fadeOutAttachmentOptions();
        setTimeout(() => {
            if (videoInput) {
                videoInput.accept = "video/*";
                videoInput.click();
            } else if (fileInput) {
                const prevAccept = fileInput.accept;
                fileInput.accept = 'video/*';
                fileInput.click();
                setTimeout(() => { fileInput.accept = prevAccept; }, 1000);
            }
        }, 400);
    });
}
if (videoInput) videoInput.addEventListener('change', () => handleFileInputs(videoInput));

if (cancelEditButton) {
    cancelEditButton.addEventListener('click', exitEditMode);
}

window.addEventListener('load', () => {
    try {
        // Re-acquire DOM references if some were null at script execution time
        chatContainer = chatContainer || document.getElementById('chatContainer');
        textInput = textInput || document.getElementById('textInput');
        sendButton = sendButton || document.getElementById('sendButton');
        voiceButton = voiceButton || document.getElementById('voiceButton');
        voiceModeIndicator = voiceModeIndicator || document.getElementById('voiceModeIndicator');

        attachmentsPreview = attachmentsPreview || document.getElementById('attachmentsPreview');
        editingMessageIndicator = editingMessageIndicator || document.getElementById('editingMessageIndicator');
        cancelEditButton = cancelEditButton || document.getElementById('cancelEditButton');
        saveToggleButton = saveToggleButton || document.getElementById('saveToggleButton');
        saveToggleIcon = saveToggleIcon || document.getElementById('saveToggleIcon');
        saveToggleCheck = saveToggleCheck || document.getElementById('saveToggleCheck');
        newChatPencilButton = newChatPencilButton || document.getElementById('newChatPencilButton');
        menuButton = menuButton || document.getElementById('menuButton');
        menuOverlay = menuOverlay || document.getElementById('menuOverlay');
        chatList = chatList || document.getElementById('chatList');
        newChatButton = newChatButton || document.getElementById('newChatButton');
        deleteAllChatsButton = deleteAllChatsButton || document.getElementById('deleteAllChatsButton');
        attachmentButton = attachmentButton || document.getElementById('attachmentButton');
        attachmentOptions = attachmentOptions || document.getElementById('attachmentOptions');
        photoInput = photoInput || document.getElementById('photoInput');
        fileInput = fileInput || document.getElementById('fileInput');
        cameraInput = cameraInput || document.getElementById('cameraInput');
        videoInput = videoInput || document.getElementById('videoInput');
        stopButton = stopButton || document.getElementById('stopButton');
        welcomeScreen = welcomeScreen || document.getElementById('welcomeScreen');
        chatContainerTemporaryMessage = chatContainerTemporaryMessage || document.getElementById('chatContainerTemporaryMessage');
        menuTemporaryMessage = menuTemporaryMessage || document.getElementById('menuTemporaryMessage');

        initSaveToggleState();
        loadChatsList();
        if(db) {
            getUserMemory().then(memories => {
                const userName = (memories || []).find(m => m.key === 'name')?.value;
                if (userName) {
                    console.log(`Ryo يتذكر اسمك: ${userName}`);
                }
            }).catch(err => console.error("getUserMemory failed on load:", err));
        }

        if (textInput) textInput.dispatchEvent(new Event('input'));

        // Ensure send/voice initial visibility is correct on load
        setSendingUI(false);
    } catch (err) {
        console.error("window.load handler error:", err);
    }
});

// Expose commonly used functions for non-module inline scripts
try {
    window.loadChatsList = loadChatsList;
    window.sendMessage = sendMessage;
    window.startVoiceMode = startVoiceMode;
    window.stopVoiceMode = stopVoiceMode;
    window.startNewChat = startNewChat;
    window.startEditMode = startEditMode;
    window.exitEditMode = exitEditMode;
} catch (e) {}

// STOP button: abort active request and update UI
if (stopButton) {
    stopButton.addEventListener('click', () => {
        try {
            if (controller) {
                controller.abort();
            }
            if (isSpeaking && synthesis) synthesis.cancel();
            setSendingUI(false);
            if (loadingMessageElement) {
                try { loadingMessageElement.remove(); } catch(e) {}
                loadingMessageElement = null;
            }
            createMessageElement('تم إيقاف العملية بواسطة المستخدم.', 'ai');
        } catch (err) {
            console.error("stopButton handler error:", err);
        }
    });
}

window.addEventListener('beforeunload', () => {
    try {
        if (controller) controller.abort();
    } catch (e) {}
    try {
        if (synthesis) synthesis.cancel();
    } catch (e) {}
});

// MutationObserver to finalize code blocks inserted dynamically
(function initCodeBlockObserver() {
    try {
        const observerTarget = chatContainer || document.body;
        const mo = new MutationObserver((mutations) => {
            mutations.forEach(m => {
                if (m.addedNodes && m.addedNodes.length) {
                    m.addedNodes.forEach(node => {
                        try {
                            if (!(node instanceof HTMLElement)) return;
                            if (node.matches && node.matches('.code-block-container')) {
                                finalizeMessageDisplay(node.parentElement || node);
                            } else {
                                node.querySelectorAll && node.querySelectorAll('.code-block-container').forEach(cb => {
                                    finalizeMessageDisplay(cb.parentElement || cb);
                                });
                                // Also attach finalize for newly added message content wrappers
                                if (node.querySelectorAll) {
                                    node.querySelectorAll && node.querySelectorAll('.ai-message-content, .user-message-content, .loading-message').forEach(el => {
                                        finalizeMessageDisplay(el);
                                    });
                                }
                            }
                        } catch (err) {}
                    });
                }
            });
        });
        mo.observe(observerTarget, { childList: true, subtree: true });
    } catch (err) {
        console.warn("Code block MutationObserver setup failed:", err);
    }
})();
