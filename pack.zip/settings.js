// settings.js - الكود المحدث بالكامل لإلغاء جميع الوظائف
document.addEventListener('DOMContentLoaded', () => {
    // === متغيرات الإعدادات الأساسية ===
    const settingsOverlay = document.getElementById('settingsOverlay');
    const settingsButton = document.getElementById('settingsButton');
    const closeSettingsButton = document.getElementById('closeSettingsButton');
    
    // === وظائف فتح/إغلاق الإعدادات الأساسية فقط ===
    settingsButton.addEventListener('click', (event) => {
        event.stopPropagation(); 
        
        // إغلاق قائمة المنيو الجانبية إذا كانت مفتوحة
        const menuOverlay = document.getElementById('menuOverlay');
        if (menuOverlay) {
            menuOverlay.classList.remove('open'); 
        }
        
        // فتح شاشة الإعدادات
        settingsOverlay.classList.add('open');
    });

    closeSettingsButton.addEventListener('click', () => {
        // إغلاق شاشة الإعدادات
        settingsOverlay.classList.remove('open');
    });

    // تم إلغاء جميع وظائف الإعدادات (الوضع الداكن، اللغة، الموسيقى، إلخ)
    // لا يتم تحميل أو حفظ أو تطبيق أي إعدادات هنا.
});
